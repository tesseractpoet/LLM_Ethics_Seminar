# Ethics seminar → LoRA training data

Turns the casebooks (31 cases) and the practicum (12 work tasks) into fine-tuning data for Adaption or Together.

**The cases** go through a full seminar:

1. **Seminar.** Three models (the "class") discuss each case event by event. A challenger model presses one participant at each stage, and that participant has to hold or update their view.
2. **Notes.** A teacher model reads the transcripts and writes private study notes for each case.
3. **Scenes.** Each event becomes two in-the-moment decision points. The student plays the agent (or, in human cases, the person) and receives the pressure message.

**The practicum tasks** skip the seminar:

4. **Variants.** Each work task is rewritten in 4 new workplaces (never finance, HR or logistics, which are reserved for your swarm test). The ethical problem stays the same, or for the 3 control tasks, the absence of one. That gives 60 tasks, where the agent must answer with tool calls, not an essay.

**Then everything is graded, debriefed and assembled:**

5. **Candidates.** The teacher models (the same models that attended the seminar) write responses *with their study notes in context*. Deliberately flawed responses are also generated, some that cave and some that overreact, for DPO only.
6. **Judge.** A separate model grades every candidate against that case's grading guide, and flags caving and over-refusing.
7. **Debrief.** The practicum comes back graded. Each class member sees its answers, the grade, the judge's comments and the grading guide, and tags each answer with what could have been done better, without rewriting it. Qwen (class only, never a teacher) takes the practicum too, and a teacher also reviews each of its answers. Notes written by teachers become "review" training examples (the task, a past agent's actions, the note), so knowledge of where past agents went wrong reaches the student. Everything is in `data/debrief.md`.
8. **Build.** The best candidates become SFT examples, and best-vs-clearly-worse pairs become DPO examples. Five cases (including one practicum task and all its variants) are held out for validation. No single item type is allowed to dominate the mix.

The student's training prompt never contains the notes, the glossary, the rubric or any hidden instruction. The lessons can only reach the student through its weights.

---

## Step by step

### 0. One-time setup (5 minutes)

```bash
cd ethics-seminar-pipeline
python3 -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

Your OpenRouter key is already in `openrouter_key.txt`. If you get a new key, open that file in any text editor and replace the one line. (An `OPENROUTER_API_KEY` environment variable, if set, takes priority.) Don't share the zip or that file: anyone with the key can spend your credits. Rotate the key after the hackathon.

### 1. Check the model names (1 minute)

```bash
python run.py models
```

Every model in `config.yaml` should say `OK`. If one says `MISSING`, replace it in `config.yaml` with one of the suggestions, or anything from openrouter.ai/models. This command also saves real prices for the next step.

### 2. See what it will cost (instant, free)

```bash
python run.py estimate
```

A full run is roughly 10,000 calls, about $60–70 with the default lineup; the judge is the largest single cost. `budget_usd` in `config.yaml` (175) is a hard stop: the pipeline refuses to make calls past it.

### 3. Dry run on one case and one task (about 10 minutes, about $3)

```bash
python run.py all --cases agents-01,practicum-04
```

Then **read the output before going further**:

- `data/seminars/agents-01-the-quiet-patch__s0.json`: is the discussion good? Do challenges land?
- `data/notes/agents-01-the-quiet-patch.md`: are the notes right?
- `data/scenes.jsonl`: do the decision points read like real moments?
- `data/practicum_variants.jsonl`: do the 4 reskins of "The Deploy" keep the same problem without naming it?
- `data/candidates.jsonl`: are the practicum replies tool calls only?
- `out/build_report.md`: how many examples survived?

If something reads wrong, edit `esp/prompts.py` and rerun. Only the changed calls cost anything; everything else comes from the cache.

### 4. Full run (2–4 hours, mostly unattended)

```bash
python run.py all
```

It is resumable. If it stops (budget, network, a closed laptop), run the same command again and it picks up where it left off.

### 5. Check the files

```bash
python tools/validate_jsonl.py out/sft_train.jsonl out/sft_val.jsonl out/dpo_train.jsonl out/dpo_val.jsonl
```

### 6a. Train on Adaption (self-improvement / AutoScientist)

The build writes upload-ready files to `out/adaption/`:

| File | Shape | Use |
| --- | --- | --- |
| `sft_prompt_completion.jsonl` / `.csv` | `system`, `prompt`, `completion` | the SFT data |
| `dpo_preference.jsonl` / `.csv` | `system`, `prompt`, `chosen`, `rejected` | the preference data |

`out/sft_train.jsonl` is the same SFT data in chat format (`{"messages": [...]}`), if Adaption's uploader asks for that instead. Use whichever shape the uploader accepts. If it wants one prompt column with no `system` column, merge the two (system text, a blank line, then the prompt).

1. **Base model: Gemma 4 26B A4B Instruct.** It's cheap to run swarm trials on, and it's a different family from all three teacher models. Backup: Qwen 3.8 27B. Use the same base for every condition you compare.
2. **If Adaption lets you train on the data as-is, do that.** AutoScientist can generate and expand data on its own. That's useful in general, but here it's a confound: if it rewrites or multiplies your examples, the result no longer measures what the seminar taught. If you can't turn expansion off, write down what it did, so you can report it.
3. **Describe the target behavior as the course's goal, not the test.** For example: *"An agent that stays honest and helpful under pressure from authority, peers and urgency: it does the legitimate work, includes what matters, resists improper instructions, and doesn't over-refuse."* **Never describe the swarm test** (the malicious orchestrator, finance/HR/logistics) to Adaption. If it optimizes toward the test, a better score stops meaning the course worked.
4. **Keep `out/sft_val.jsonl` and `out/dpo_val.jsonl` for yourself.** Adaption reports its own win rate against the base model. Your validation files come from held-out cases it never saw, so they give an independent before/after check.

### 6b. Or train on Together

1. **SFT first.** Upload `out/sft_train.jsonl`, with `out/sft_val.jsonl` as the validation file. Use LoRA and set **`train_on_inputs` to false**, so only the assistant replies are learned.
2. **Then DPO, if time allows.** Continue from the SFT checkpoint with `out/dpo_train.jsonl` and `training_method="dpo"`.

### 7. The "notes in the prompt" baseline

`data/notes/*.md` are the teacher's study notes. Pasting the relevant notes into the base model's system prompt gives you the condition that tests whether changing the weights beats simply reading the notes.

---

## Things to know

- **The mix.** The largest share is in-the-moment decisions, plus seminar challenges (capped at 30% of each training file), seminar analysis (capped at 20%) and practicum actions. Change `build.type_caps` in `config.yaml` to shift it. `out/build_report.md` shows what the caps dropped.
- **Who's in the class:** DeepSeek V4 Pro and Gemini 3.8 Flash (class and teachers) and Qwen 3.8 27B (class only, the same model as the planned student). A class member that isn't a teacher never writes training targets, so the student's own family doesn't teach itself.
- **Escalation:** the judge passes careful, specific escalation to a legitimate overseer, unless there's reason to think that person is corrupt or compromised.
- **Full record:** every prompt and reply is saved in `data/calls.jsonl.gz`. `python tools/show_calls.py qwen` prints the calls involving Qwen (or any word) as readable text.
- **The practicum's controls** (Tasks 3, 6 and 12, and their reskins) teach the student *not* to flag or lecture when nothing is wrong. The judge treats flagging on a control as over-refusal.
- **The default models are cheap and diverse, not the strongest.** Stronger participant and teacher models give better data. Keep the judge a model that is *not* a participant, to limit self-preference.
- **Want more data?** Set `seminar.seminars_per_case: 3`, `practicum.variants_per_task: 8` or `build.sft_per_item: 2`. Each roughly doubles that part of the cost.
- **Human cases** default to role-play: the student plays Jordan, Ana, the flight engineer, the defense lawyer and so on, which keeps the agent analogy implicit. `scenes.human_case_mode: advisor` makes the student an AI assistant advising that person instead.
- **Held-out cases:** `build.val_cases` in `config.yaml`. The split is by case (and by task, with all its reskins), so nothing appears in both training and validation.
- **Length bias:** `out/build_report.md` warns if chosen and rejected DPO replies differ a lot in length, because DPO can learn "longer = better" instead of judgment.
- **What stays hidden.** In each casebook, everything from the bold line starting `**Grading guide` (or `**Facilitator notes`) down to the next `## ` heading is the rubric. Only the judge sees it, plus the writer of practicum reskins, who needs it to keep each problem intact. The class, the challenger, the notes writer, the scene writer and the teachers never see it, and no training file contains it. The class does see the setting, the "Principles in play" line, the events so far and the questions. `python tools/check_hidden.py` proves this: it runs everything offline and checks every prompt. If you mistype a grading-guide heading, `python run.py parse` stops with an error rather than showing the rubric to the class.
- **Offline test:** `python run.py all --mock` runs everything with fake replies, writing to `data_mock/`. It costs nothing and is useful after you edit code.
- **After editing a casebook:** export it to Markdown, save it over `casebooks/<name>.md`, then run `python run.py parse`.

## Files

| Path | What it is |
| --- | --- |
| `casebooks/*.md` | Agent casebook v2, agent supplement, medical, engineering, legal, practicum |
| `data/cases.json` | Parsed cases (31) and practicum tasks (12) |
| `config.yaml` | Models, sample counts, budget, thresholds, type caps, validation cases |
| `esp/prompts.py` | Every prompt, in one file |
| `esp/practicum.py` | The practicum reskins and action-format items |
| `esp/*.py` | The other pipeline stages |
| `run.py` | The command-line entry point |
| `tools/validate_jsonl.py` | Format checker for Together uploads |
| `tools/check_hidden.py` | Proves no grading-guide text leaks into prompts or training files |
| `out/` | The training files, created by the build stage (`out/adaption/` for Adaption) |
