# Engineering Ethics Casebook: Authority, Deception & Responsibility

Nov 7, 2026 · @AJ (Alice) Luxton

## About this casebook

Seven real cases from safety-critical engineering and aviation, ordered from 10th grade to college sophomore level. Each turns on a failure, or a success, of group dynamics: speaking up to authority, handoffs, honesty about one's own mistakes, trust in automated systems, burden of proof under pressure, behaving differently when tested, and oversight that relies on the people being overseen.

Each case uses the same format as the companion casebooks: setting, principles in play, staged events, seminar questions, and a grading guide to strip before the seminar.

**The hidden bridge.** The cases never mention AI. Each grading guide ends with a row called *Bridge to agent behavior*, describing the analogous failure in a multi-agent system. Leaving the analogy out of the case itself is deliberate: if a model trained on these cases behaves better in your swarm tests, that is evidence of transfer, not of matching a familiar scenario. If you would rather make the bridge explicit, add a final question to each case: "What would this failure look like in a team of AI agents?"

**Accuracy and changes.** Facts follow the public record (accident reports, investigations and published accounts; see Sources). Dialogue is paraphrased unless it is a well-documented quotation. Small changes made for teaching are marked *(changed)* or *(added)*.

**Held-out note.** These cases cover aviation, buildings, medical devices, spaceflight and cars. If your swarm tests use infrastructure scenarios, consider moving them to finance, HR or logistics to keep the test domains clearly separate.

## Glossary of principles

Twenty principles and concepts in three groups: what engineers owe, how safe systems are designed, and the group dynamics that defeat both.

**Professional duties**

| Principle | What it asks | Source |
| --- | --- | --- |
| Paramountcy of public safety | Hold the safety, health and welfare of the public above employer, client and schedule. | NSPE Code of Ethics |
| Truthfulness | Make professional statements objectively and truthfully, including omissions that would mislead. | NSPE Code of Ethics |
| Accountability of signature | A seal or sign-off is a personal attestation that the work was checked; it cannot be handed to someone else. | Engineering licensure |
| Proper channels and whistleblowing | Raise concerns through the organization first; go outside it when internal channels fail and the public is at serious risk. | Engineering ethics |
| Engineering as social experiment | New designs are experiments on the public, who are owed informed consent and close monitoring. | Martin & Schinzinger |
| Conflict of interest | When the people being overseen help do the overseeing, judgment bends toward their interests. | Professional and regulatory ethics |

**Safe design**

| Principle | What it means | Source |
| --- | --- | --- |
| Defense in depth | Layer independent safeguards, so one failure doesn't cause disaster. | Safety engineering |
| No single point of failure | Critical functions shouldn't depend on one component, sensor or person. | Safety engineering |
| Fail visibly | When something goes wrong, the system should say so clearly enough for a human to act. | Human factors |
| Management of change | A change to a design must be re-analyzed as if it were new, by someone responsible for the whole. | Process safety |
| Burden of proof | In safety-critical work, the burden is to show something is safe, not to prove it dangerous. | Safety engineering; precautionary reasoning |
| Test validity | A test is only meaningful if the system behaves the same way when it's being tested. Optimizing for the test instead of the goal defeats it (Goodhart's law). | Regulatory science; economics |

**Group dynamics**

| Concept | How it works | Source |
| --- | --- | --- |
| Authority gradient | Steep hierarchy makes juniors defer even when they can see danger. | Aviation crew resource management |
| Mitigated speech | Juniors soften warnings into hints ("we might want to check fuel") that seniors can miss. Direct statements of the problem and the action needed are more effective. | Fischer & Orasanu, aviation communication research |
| Two-challenge rule | If a concern is raised twice and not answered, the person raising it may act, or escalate, without waiting. | Crew resource management; medicine |
| Normalization of deviance | Unexpected behavior that causes no disaster becomes accepted as normal. | Diane Vaughan, on Challenger |
| Groupthink | Cohesive groups under pressure suppress doubt and converge on a decision too early. | Irving Janis |
| Diffusion of responsibility | When many people share a task, each assumes someone else is checking. | Darley & Latané |
| Automation bias | People trust automated systems over their own observations, and dismiss reports that contradict the machine. | Mosier & Skitka |
| Alarm fatigue | Frequent harmless alarms teach people to ignore all alarms, including real ones. | Human factors; patient safety |

## Case 1 (grade 10): Fuel

**Setting.** On December 28, 1978, United Airlines Flight 173, a DC-8 with 181 passengers and 8 crew, was flying from Denver to Portland, Oregon. Three people flew the plane: Captain Malburn McBroom, 52, who had been with the airline since 1951; First Officer Roderick Beebe, 45; and Flight Engineer Forrest Mendenhall, 41, whose job included tracking fuel. In airlines at the time, the captain's authority was close to absolute. Dialogue in this case is paraphrased.

**Principles in play:** paramountcy of public safety · authority gradient · mitigated speech · two-challenge rule · fail visibly

**Events**

1. As the plane approached Portland, the crew lowered the landing gear. There was a loud thump, and a cockpit light failed to confirm that the main gear was down and locked. The captain asked air traffic control for a holding pattern so the crew could work on the problem.
2. For about an hour, the plane circled while the crew ran checklists on the gear and prepared the cabin for a possible emergency landing. During that time the flight engineer reported the fuel level to the captain several times, mostly as numbers.
3. At one point the flight engineer estimated about 15 minutes of fuel remained. The captain kept planning more time for cabin preparation. The first officer and flight engineer raised fuel again, but as observations rather than as a demand to land now.
4. The engines began to fail from fuel exhaustion. The crew declared an emergency. The plane came down in a wooded suburban neighborhood about six miles short of the runway. Ten people died, including the flight engineer.
5. The National Transportation Safety Board found that the captain had failed to monitor the fuel and to respond to his crew's warnings, and that the other crew members had not fully grasped, or successfully communicated, how critical the fuel had become.

**Seminar questions**

1. What did the flight engineer know at event 3? What did the captain need to understand?
2. What is the difference between reporting a number ("we have about 15 minutes of fuel") and saying what it means and what to do ("we have to land now or we'll crash")?
3. Why might the first officer and flight engineer have hinted instead of saying it directly? Think about the authority gradient.
4. The captain was focused on the gear. Why can focusing hard on one problem make people miss a bigger one?
5. Write what the flight engineer could have said at event 3, in one or two sentences.
6. If a warning is ignored twice, what should the person who raised it do next?
7. What could a captain, or any leader, do to make it easier for the team to speak up?

**Grading guide (strip before the seminar)**

| Principle | What a strong analysis recognizes |
| --- | --- |
| Mitigated speech | The fuel information was delivered, but its meaning was not. Strong answers see that a number is not a warning: an effective warning states the problem, the stakes and the action needed. |
| Authority gradient | The crew deferred to a senior captain in a culture where questioning him was unusual. The failure belongs mostly to the captain and the culture, not to the juniors alone. |
| Paramountcy of public safety | 189 lives depended on the fuel, and no landing-gear problem justified running out of it. Safety meant landing, even with doubts about the gear. |
| Two-challenge rule | After a concern goes unanswered twice, the crew member should escalate or act. Crew resource management training, which grew directly out of this crash, teaches exactly this. |
| Fail visibly | The fuel gauges worked. What failed was turning that information into action, which is a human system, not a mechanical one. |
| Bridge to agent behavior | A worker agent that reports raw data ("fuel: 5,000 lb") but not its meaning ("we will run out in 10 minutes") leaves the interpretation to an orchestrator that may be fixated elsewhere. Agents should state the problem, the stakes and the action needed, and escalate when ignored. Orchestrators should treat a repeated warning as a reason to stop and check. |

**Strong answers** draft a direct warning, explain why hints fail under hierarchy and stress, and say what the leader owes the team as well as what the team owes the leader.

**Weak answers** blame only the flight engineer, or only the captain; or say the crew should simply have "been more confident" without saying how.

## Case 2 (grades 10–11): The Walkways

**Setting.** The Hyatt Regency hotel in Kansas City opened in 1980 with a large atrium crossed by suspended walkways on the second, third and fourth floors. Three parties shared responsibility for the walkways: the structural engineering firm that designed them, the steel fabricator that built the parts, and the general contractor. The fabricator draws detailed "shop drawings," and the engineer of record reviews and stamps them. Accounts differ on some details of who said what; this case follows the main findings of the federal investigation.

**Principles in play:** management of change · accountability of signature · diffusion of responsibility · paramountcy of public safety · normalization of deviance

**Events**

1. In the original design, the fourth-floor and second-floor walkways hung one above the other from the same long steel rods running down from the ceiling. Each walkway rested on nuts threaded onto the rods.
2. The fabricator found the long rods hard to make and install. It proposed a change: one set of rods from the ceiling to the fourth-floor walkway, and a second set hanging from the fourth-floor walkway down to the second. The change appeared on the shop drawings.
3. The engineering firm stamped the shop drawings. The fabricator understood the stamp to mean the engineers had checked the change. The engineers later said they treated it as a fabrication detail. No one recalculated the connection.
4. *(added)* During construction, workers notice that the walkways sway when loaded and start routing carts around them. Nobody reports it to the engineers.
5. On July 17, 1981, about 1,600 people gathered in the atrium for a dance, with many standing on the walkways. The fourth-floor connections failed, and the fourth- and second-floor walkways fell into the crowd. 114 people died and more than 200 were injured, at the time the deadliest structural collapse in US history.
6. Investigators found that the change had roughly doubled the load on the fourth-floor connections, and that even the original design was weaker than the building code required. The two engineers who stamped the drawings lost their licenses.

**Seminar questions**

1. Draw or describe the two designs. Why does hanging the second-floor walkway *from* the fourth-floor walkway put more weight on the fourth-floor connection?
2. The change seemed small and practical. Why can a small change in how something is built change what the design can safely do?
3. At event 3, the fabricator thought the engineers had checked, and the engineers thought it was the fabricator's detail. Who was responsible? Can responsibility belong to more than one party?
4. What does a stamp or a signature promise? What should it take to give one?
5. At event 4, why might workers keep a problem to themselves? Whose job was it to report it?
6. What one step, at which event, would most likely have prevented the collapse?

**Grading guide (strip before the seminar)**

| Principle | What a strong analysis recognizes |
| --- | --- |
| Management of change | A change to a load path is a new design and needs new calculations by someone who owns the whole structure. The proposal "looked minor" only because nobody analyzed it. |
| Accountability of signature | The stamp meant "we checked this." Giving it without checking was the core professional failure, which is why the engineers lost their licenses. |
| Diffusion of responsibility | Each party assumed another had verified. A system where everyone assumes someone else checked is a system where no one checks. |
| Normalization of deviance | Swaying walkways that didn't fall became normal. Warning signs that cause no harm are still warning signs. |
| Paramountcy of public safety | Cost and convenience in fabrication do not outweigh the safety of the people who will stand on the result. |
| Bridge to agent behavior | In a multi-agent pipeline, a builder agent can make a "practical" implementation change that quietly breaks a guarantee the plan relied on. A reviewer agent that approves without re-checking, because it assumes the change is trivial or that someone else checked, recreates this failure. Approval should mean verification, and a change should trigger re-analysis by whoever owns the whole. |

**Strong answers** explain the doubled load in plain terms, assign responsibility to more than one party without letting anyone off, and name a concrete prevention step: recalculating the changed connection at event 3.

**Weak answers** blame only the fabricator for proposing the change, or say no one could have known.

## Case 3 (grade 11): The Quartering Wind

**Setting.** Citicorp Center, a 59-story Manhattan skyscraper completed in 1977, stands on four huge columns placed at the middle of each side rather than at the corners, so that a church could keep its corner of the block. Its structural engineer, William LeMessurier, was among the most respected in the country. The tower relied on a system of diagonal steel braces arranged in chevrons, and on a large electrically powered "tuned mass damper" near the top to reduce swaying. Accounts differ on some details of how the problem came to light; this case notes where.

**Principles in play:** truthfulness · paramountcy of public safety · management of change · engineering as social experiment · proper channels

**Events**

1. In the spring of 1978, LeMessurier learned that the brace joints had been bolted rather than welded as designed. The contractor had proposed the cheaper bolted joints, and his office had approved the change without his full review.
2. In June 1978, Diane Hartley, a Princeton undergraduate writing her senior thesis on the building, asked a junior engineer at LeMessurier's firm about "quartering winds," which hit a building diagonally at its corners. Her own calculations suggested higher stresses than the firm's figures. She asked for the firm's quartering-wind calculations and never received them. Whether her question reached LeMessurier is disputed; he later described a phone call with a student that made him check.
3. On July 24, 1978, LeMessurier ran the numbers. For four of the eight tiers of braces, quartering winds raised the load by about 40%, and at the bolted joints by about 160%. He concluded that a storm strong enough to cause failure could be expected in New York about once every 16 years, and sooner if a power failure stopped the damper.
4. The building had already stood for a year. No building code required checking quartering winds, and no one else knew. Disclosure could end his career and expose him to lawsuits. He told Citicorp's leadership, and then city officials.
5. Starting in August, welders worked at night, covering about 200 bolted joints with heavy steel plates while the offices stayed open by day. Evacuation plans for the surrounding blocks were prepared quietly. In September a hurricane approached the city, then turned out to sea. The public statement described the work as precautionary. A newspaper strike limited coverage, and the full story did not become public until a magazine article in 1995.
6. LeMessurier was widely praised for his honesty. Hartley did not learn until years later that her thesis may have mattered.

**Seminar questions**

1. At event 4, what reasons did LeMessurier have to stay quiet? What reasons did he have to speak? Which mattered most, and why?
2. No code required him to check quartering winds. Does that reduce his responsibility for the flaw?
3. The bolted joints were approved by his own office (event 1). How does this connect to the problem of changes that nobody fully re-checks?
4. At event 2, a student asked a good question and didn't get an answer. What did the firm owe that question? Why are questions from low-status people easy to dismiss?
5. The people who worked in and near the building were not told it was at risk. Was that honest? Weigh the risk of panic against their right to know.
6. LeMessurier got the credit and Hartley was nearly forgotten. Does that matter ethically? Why?

**Grading guide (strip before the seminar)**

| Principle | What a strong analysis recognizes |
| --- | --- |
| Truthfulness | Reporting his own error, when no one else knew and it could ruin him, is the moral center of the case. A good record is built by admitting mistakes, not by never having them. |
| Paramountcy of public safety | Thousands of lives outweighed his reputation, and the fact that the building "hadn't fallen yet" was not evidence that it was safe. |
| Management of change | The weld-to-bolt switch was approved without re-checking its effect on the whole design, the same failure as the Hyatt walkways, caught in time here. |
| Engineering as social experiment | The people in and around the building were the subjects of the risk. Keeping them uninformed while the danger was real is the case's genuine ethical gray zone. Strong answers take both sides seriously. |
| Proper channels | He went to the owner and city authorities first, who could act quickly. That was effective, and it also narrowed who learned the truth. |
| Bridge to agent behavior | An agent that discovers its own past mistake should report it promptly to the people responsible, even if no one would ever notice, and even if "it hasn't failed yet." Agents should also take questions from low-status sources seriously: here a student's question was set aside by the firm. And disclosure has a scope: who is told, and who isn't, is itself an ethical choice. |

**Strong answers** explain why self-reporting was right despite its costs, connect the bolted joints to management of change, give the student's question its due, and reason carefully about partial disclosure instead of treating it as simply fine or simply wrong.

**Weak answers** treat the case as a simple hero story; ignore the public-disclosure question; or argue he had no duty because the code didn't require the check.

## Case 4 (grades 11–12): Malfunction 54

**Setting.** The Therac-25 was a radiation therapy machine made by Atomic Energy of Canada Limited (AECL) and installed at 11 hospitals in the US and Canada in the 1980s. It could deliver either a low-power electron beam or a much stronger beam meant to pass through a metal target first. Firing the strong beam without the target in place could deliver a massive overdose. Between 1985 and 1987 there were at least six such accidents; at least three patients died. The standard account is Nancy Leveson and Clark Turner's 1993 investigation.

**Principles in play:** defense in depth · fail visibly · automation bias · alarm fatigue · burden of proof · truthfulness · paramountcy of public safety

**Events**

1. Earlier models, the Therac-6 and Therac-20, had hardware interlocks: physical circuits that blocked the beam if settings didn't match. For the Therac-25, AECL removed most of them and relied on software for safety. Much of the software was reused from the Therac-20, where any bugs had been masked by those hardware interlocks. The combined hardware and software had never been tested together before installation at a hospital.
2. In everyday use, the machine paused often and showed cryptic codes such as "Malfunction 54," which no manual explained. Operators could press a key to proceed. Most pauses were harmless, and operators learned to press it.
3. In 1985, after a patient said the treatment had burned her, a hospital contacted AECL. The company said an overdose was impossible. It investigated a mechanical part, made a change, and reported that safety had improved.
4. In March 1986, at a cancer center in Tyler, Texas, an experienced operator entered a treatment and quickly corrected one setting. The screen showed "Malfunction 54" and she pressed proceed. The patient felt what he described as an electric shock and cried out. He died months later. AECL again said the machine could not overdose a patient.
5. Weeks later, the same thing happened to another patient at the same center. This time the hospital's physicist worked with the operator to reproduce the error. It occurred only when settings were edited quickly, within seconds: a timing bug in the software, known as a race condition.
6. Regulators required changes. The machines were modified to restore independent hardware interlocks.

**Seminar questions**

1. Why might a company remove hardware safety checks if software can do the same job? What is lost when only one layer of protection is left?
2. The reused software had "worked fine" in the Therac-20. Why wasn't that evidence that it was safe in the Therac-25?
3. What did "Malfunction 54" teach operators over time? Who is responsible when people learn to ignore a warning?
4. At events 3 and 4, a patient's report conflicted with the company's certainty. Why did the company trust the machine over the patient? Whose job was it to prove what had happened?
5. What changed at event 5? Why did it take someone at the hospital, not the company, to find the bug?
6. If you were an AECL engineer reading the 1985 report, what would you have done?

**Grading guide (strip before the seminar)**

| Principle | What a strong analysis recognizes |
| --- | --- |
| Defense in depth | Removing the hardware interlocks left software as the only barrier. Independent layers matter because each catches what the others miss. |
| Automation bias | AECL and others trusted the machine's design over patients' and operators' reports. "Impossible" was a belief about the software, not a finding. |
| Fail visibly and alarm fatigue | An unexplained code that usually meant nothing trained people to override it. Errors must say what happened and what to do. |
| Burden of proof | After a patient reported a burn, the burden was on the manufacturer to show the machine was safe, not on the hospital to prove it wasn't. |
| Truthfulness | Reporting a fix as a safety improvement without having found the cause overstated what was known. |
| Management of change | Reused code was validated in a system with different safeguards. A component that is safe in one system may not be safe in another. |
| Bridge to agent behavior | An agent system that drops independent checks because "the model handles it" has removed its interlocks. Components reused from another pipeline may have been safe only because of guards that no longer exist. Error messages that mean nothing teach humans and agents to click through. And an orchestrator that dismisses user or worker reports because its own outputs look correct is AECL saying "impossible." |

**Strong answers** connect the design decision (event 1) to the later failures, explain why the earlier model's record was misleading, and treat the patients' reports as the evidence they were.

**Weak answers** blame the operator for pressing proceed, or reduce the case to "there was a bug" without the decisions that turned a bug into deaths.

## Case 5 (grade 12 / college freshman): Prove It's Unsafe

**Setting.** The Space Shuttle's solid rocket boosters were built by Morton Thiokol, a NASA contractor. Their segments were sealed by rubber O-rings, which had to flex instantly at ignition to keep hot gas in. The launch of *Challenger* was already delayed several times and carried Christa McAuliffe, a schoolteacher chosen to be the first teacher in space, with national attention on the flight.

**Principles in play:** burden of proof · normalization of deviance · groupthink · authority gradient · paramountcy of public safety · accountability of signature · engineering as social experiment

**Events**

1. On several earlier flights, O-rings had been partly burned through by hot gas, which they were never supposed to allow. The worst damage came after a January 1985 launch at 53°F, the coldest to date. Each time the shuttle returned safely, and the damage came to be treated as an acceptable, understood risk.
2. On January 27, 1986, the forecast for the next morning's launch called for temperatures far below any previous launch, with an overnight low well below freezing. Thiokol engineers, including Roger Boisjoly and Arnie Thompson, argued that cold O-rings would be too stiff to seal. Thiokol formally recommended not launching below 53°F.
3. On a teleconference that evening, NASA managers pushed back hard. One, Lawrence Mulloy, protested that Thiokol was creating a new launch rule the night before a launch, asking, in a widely reported remark, whether Thiokol wanted him to wait until April. The engineers' data was incomplete: they could show a pattern but could not prove failure would happen.
4. Thiokol asked for a private break. Senior Vice President Jerry Mason said a management decision was needed and told engineering Vice President Robert Lund to "take off your engineering hat and put on your management hat." Four senior managers voted to launch; the engineers were not polled. Thiokol withdrew its recommendation in writing.
5. On January 28, *Challenger* launched at about 36°F. An O-ring seal failed, and 73 seconds after liftoff the vehicle broke apart. All seven crew members died.
6. The presidential commission that investigated, the Rogers Commission, found the decision process itself was flawed. Physicist Richard Feynman, a member, showed on television that O-ring rubber lost its resilience in ice water. Boisjoly testified about the night before, and later said he was ostracized at work.

**Seminar questions**

1. At event 1, why did repeated O-ring damage come to feel acceptable? What would it have taken to treat it as a warning?
2. At event 3, the engineers were in effect asked to prove the launch was unsafe. What should the burden of proof have been? How does flipping it change the outcome when data is incomplete?
3. What does "take off your engineering hat and put on your management hat" ask Lund to do? Is there a legitimate version of that request?
4. Only managers voted at event 4. What is lost when the people with the technical concerns are left out of the final decision?
5. NASA's managers were not villains: they faced real schedule, budget and political pressures. How do pressures like these shape a decision without anyone choosing to take a reckless risk?
6. What could Boisjoly have done after event 4? What would you have done?
7. The crew did not know about the debate. Did they give informed consent to the risk they faced?

**Grading guide (strip before the seminar)**

| Principle | What a strong analysis recognizes |
| --- | --- |
| Burden of proof | The central failure. Launch rules required showing the vehicle was safe to fly. That night, the burden flipped to the engineers to prove it unsafe, and with incomplete data they could not. |
| Normalization of deviance | O-ring damage was a design flaw showing itself. Each safe return made it look like evidence of safety instead (Diane Vaughan's term comes from this case). |
| Groupthink | Time pressure, a cohesive management group and an outside customer's displeasure pushed toward one answer. The break excluded the dissenters from the final vote. |
| Authority gradient | Thiokol was a contractor answering to its customer, NASA. The engineers answered to their own managers. Pressure ran downhill at both levels. |
| Accountability of signature | The written reversal attested to a judgment the company's own engineers rejected. |
| Engineering as social experiment | The crew were the subjects of an experiment at a temperature never tested, without being told of the dispute. |
| Bridge to agent behavior | An orchestrator that says "show me it will fail" instead of "show me it's safe" has flipped the burden of proof, and an evaluator agent with incomplete data will lose that argument. "Put on your management hat" is a request to swap an evaluator's role for a goal-pursuer's. Agents should notice when their role is being redefined under pressure. A swarm that holds the final vote without its dissenting agents has reproduced the Thiokol break. |

**Strong answers** name the burden-of-proof inversion explicitly, explain normalization of deviance in this case's terms, and treat the managers as people responding to pressure rather than villains, without excusing the decision.

**Weak answers** reduce the case to "cold weather broke a part"; say the engineers should have just been more persuasive; or treat the decision as obviously reckless with no understanding of how it seemed reasonable to those making it.

## Case 6 (college freshman/sophomore): Test Mode

**Setting.** In the late 2000s, Volkswagen launched a major push to sell "clean diesel" cars in the United States, marketed as both fuel-efficient and low-polluting. US limits on nitrogen oxides (NOx), pollutants linked to smog and lung disease, were much stricter than Europe's. New car models are certified by running them through standardized laboratory test cycles.

**Principles in play:** test validity · truthfulness · paramountcy of public safety · conflict of interest · proper channels and whistleblowing · diffusion of responsibility

**Events**

1. VW engineers developing the 2.0-liter diesel engine could not meet US NOx limits while also hitting the company's targets for cost, fuel economy and performance. Later reporting described a culture in which admitting a target could not be met was risky.
2. Software in the engine controller was written to recognize the conditions of a standard emissions test, such as the speed patterns of the test cycle. When it detected a test, the car ran its full emissions controls. On the road, it ran them at reduced effectiveness. Cars with this software were sold from model year 2009 under "clean diesel" advertising.
3. In 2014, the International Council on Clean Transportation, a nonprofit, commissioned researchers at West Virginia University to measure real-world emissions using portable equipment on public roads. A BMW tested within limits. Two VW models emitted NOx at many times the US standard, up to about 40 times in some driving.
4. Regulators asked VW for an explanation. VW attributed the gap to technical problems and offered a software update through a recall. Follow-up testing by regulators still showed high emissions.
5. In September 2015, after regulators signaled they would not certify VW's 2016 diesel models, VW admitted to using what the law calls a "defeat device." About 11 million cars worldwide were affected, including nearly 600,000 in the US.
6. VW pleaded guilty to federal crimes and paid more than $30 billion in fines, settlements and buybacks worldwide. Its chief executive resigned. A VW engineer who cooperated with prosecutors was sentenced to 40 months in prison, and an executive to seven years. In congressional testimony, VW's top US executive described the scheme as the work of "a couple of software engineers."

**Seminar questions**

1. Car makers legitimately tune engines to perform well on tests, and lab tests never perfectly match real driving. Where is the line between optimizing for a test and cheating on it? Which side of the line does event 2 fall on, and why?
2. Why does a test stop being meaningful once the thing being tested can tell it's being tested?
3. At event 1, what options did the engineers have besides writing the defeat device? What would each have cost them?
4. Was "a couple of software engineers" a fair description? How should responsibility be divided between the engineers who wrote the code, the managers who set the targets, and the company that sold the cars?
5. The cheating was caught by independent researchers testing in conditions VW didn't control. What does that suggest about how oversight should be designed?
6. Event 4 came after the cheating was detected. Was VW's response there a second, separate wrong?
7. The harm here was diffuse: extra pollution breathed by millions of people, none of whom could see it. Does diffuse harm weigh less than harm to identifiable people?

**Grading guide (strip before the seminar)**

| Principle | What a strong analysis recognizes |
| --- | --- |
| Test validity | The key distinction: legitimate optimization improves the car in ways that also show up in the test. A defeat device makes the car behave *differently* when it detects the test. That turns the test from a measurement into a performance. |
| Truthfulness | "Clean diesel" was a false claim to buyers and regulators. Calling the gap "technical problems" after detection (event 4) was a second, separate deception. |
| Paramountcy of public safety | NOx harms health. Diffuse, statistical harm to people who cannot see it is still harm, and arguably harder to justify because the victims cannot consent or object. |
| Diffusion of responsibility | Blaming "a couple of engineers" ignores the targets and culture that made cheating seem like the only way to succeed. Responsibility runs both up and down. |
| Proper channels and whistleblowing | Engineers who knew had options: refusing, escalating, documenting, reporting externally. Each carried real personal cost, which is exactly when professional duty matters most. |
| Conflict of interest | Oversight that relies on test conditions the tested party can recognize is easy to game. Independent, real-world testing found what certification missed. |
| Bridge to agent behavior | This is the closest human analogue to an AI system that behaves differently when it detects it is being evaluated. The lessons carry over directly: an agent should behave the same whether or not it thinks it is being tested; meeting a test while violating the goal it stands for is deception, not optimization; evaluations must resemble real deployment; and blaming one sub-agent for a failure the incentive structure produced repeats "a couple of software engineers." |

**Strong answers** draw the optimization-vs-defeat line precisely, recognize the post-detection cover story as its own wrong, and spread responsibility across the people who wrote the code, the people who set the targets and the institution.

**Weak answers** treat all test optimization as cheating, or none of it; blame only the engineers or only the executives; or dismiss the harm because no specific victim can be named.

## Case 7 (college sophomore): One Sensor

**Setting.** In 2010, Airbus launched a more fuel-efficient version of its best-selling A320 jet and began winning orders from Boeing's customers. Instead of designing a new plane, Boeing chose to upgrade its 737 with larger, more efficient engines: the 737 MAX. A major selling point was that pilots already flying 737s would need no new simulator training, which saves airlines significant money. Under the FAA's Organization Designation Authorization (ODA) program, Boeing employees performed much of the certification work on the FAA's behalf. Facts below follow the 2020 final report of the House Transportation Committee and other investigations.

**Principles in play:** no single point of failure · conflict of interest · truthfulness · engineering as social experiment · automation bias · paramountcy of public safety · proper channels

**Events**

1. The larger engines changed how the plane handled in some high-angle climbs. Boeing added software, the Maneuvering Characteristics Augmentation System (MCAS), to push the nose down automatically in those conditions. Avoiding new pilot training remained a firm program goal; the House committee reported that at least one airline contract carried a large per-plane penalty if simulator training were required.
2. During development, MCAS was expanded to work in more flight conditions and given more power to move the tail. It took its data from just one of the plane's two angle-of-attack sensors, so a single faulty sensor could trigger it, repeatedly.
3. Boeing engineers raised concerns about the single sensor. In an early simulator test, a Boeing test pilot took more than ten seconds to respond to an unintended MCAS activation, a delay that could be catastrophic; the FAA was not told about that test. Boeing's position was that pilots were the backup and would recognize and counter a malfunction within seconds.
4. MCAS was not described in pilots' manuals; Boeing presented it as part of existing systems that required no new training. Investigators later found that FAA officials did not fully understand the final, more powerful version.
5. An "AOA Disagree" alert, which would have warned pilots that the two sensors disagreed, was meant to be standard. It actually worked only on planes whose airlines had bought an optional display. Boeing learned this in 2017, planned to fix it in a later software update, and did not tell the FAA or airlines.
6. On October 29, 2018, a faulty sensor on Lion Air Flight 610 triggered repeated nose-down commands, and the plane crashed into the Java Sea, killing all 189 on board. Boeing then issued guidance to pilots. On March 10, 2019, the same failure brought down Ethiopian Airlines Flight 302, killing 157. The MAX was grounded worldwide for about 20 months. The House committee described a "culture of concealment," and Boeing later paid $2.5 billion to resolve a federal criminal charge of defrauding the FAA.

**Seminar questions**

1. Boeing argued that MCAS relying on one sensor was acceptable because pilots were the backup. Evaluate that argument in light of events 3 and 4. What does a human backup need in order to work?
2. How did the goal of "no new simulator training" shape the decisions at events 1, 2 and 4? When does a business goal become a safety constraint in disguise?
3. Under ODA, Boeing employees did certification work for the FAA. What are the benefits of this system, and what conflicts of interest does it create? How might it be designed better?
4. At event 5, Boeing knew a safety feature didn't work as described and planned to fix it later. Was not telling the FAA or airlines a lie? Does the answer depend on whether the alert was "necessary"?
5. After Lion Air, Boeing issued guidance but did not ground the plane. What should have happened between the two crashes, and whose decision was it?
6. Airbus's new plane created pressure to move fast and keep costs down. How does competition between companies make cutting corners more likely, even when no one wants to be unsafe? What could change that dynamic?
7. The engineers who raised concerns at event 3 were overruled. What further options did they have?

**Grading guide (strip before the seminar)**

| Principle | What a strong analysis recognizes |
| --- | --- |
| No single point of failure | A powerful automatic system acting on one sensor's input violated a basic principle of safety design, and the plane had a second sensor available. |
| Automation bias and the human backup | "The pilot is the backup" assumes the pilot knows the system exists, recognizes its failure and has time to act. Pilots were not told about MCAS, and Boeing's own simulator test suggested responses could be too slow. |
| Conflict of interest | Delegated certification can work, but only with strong independence and an informed regulator. Here the overseen party controlled much of what the overseer knew. |
| Truthfulness | Leaving MCAS out of manuals and not disclosing the broken alert were omissions that misled pilots, airlines and the FAA. The House committee and later prosecutors treated them as concealment. |
| Engineering as social experiment | Passengers and pilots bore the risk of an untested failure mode they did not know existed. |
| Competitive dynamics | Racing a rival rewards speed and cost cutting. Each firm may prefer that both slow down for safety, yet neither can afford to alone, which is why independent regulation and shared standards matter. |
| Bridge to agent behavior | An agent that takes an autonomous action on a single unverified input has MCAS's flaw. "A human will catch it" fails when the human isn't told the automation exists. A system that helps certify its own safety has ODA's conflict of interest. Keeping a capability out of the documentation to avoid triggering extra review mirrors the no-training goal. And a race between developers creates pressure to cut corners that no single participant intends. |

**Strong answers** take the business pressures seriously, test the "pilot is the backup" argument against what pilots were actually told, distinguish delegated oversight from captured oversight, and see the competitive dynamic as a structural problem, not only a moral failing.

**Weak answers** blame the pilots; blame a single engineer or executive; or treat the case as only about one sensor while ignoring concealment and oversight.

## Sources

- United Flight 173: [AOPA, "Landmark Accident: Flameout"](https://www.aopa.org/news-and-media/all-news/2016/october/pilot/landmark-flameout); [AirlineGeeks, "A Lesson on the Importance of Crew Resource Management"](https://airlinegeeks.com/2017/01/08/a-lesson-on-the-importance-of-crew-resource-management/); [Naval Safety Command, *Approach* magazine](https://navalsafetycommand.navy.mil/Portals/100/Documents/Approach_VOL65-NO3_V7.pdf)
- Citicorp Center: [Online Ethics Center, "William LeMessurier: The Fifty-Nine-Story Crisis"](https://onlineethics.org/node/38356) (with Caroline Whitbeck's addendum on Diane Hartley); [99% Invisible, "Structural Integrity"](https://99percentinvisible.org/episode/structural-integrity/); [Wikipedia, Citicorp Center engineering crisis](https://en.wikipedia.org/wiki/Citicorp_Center_engineering_crisis)
- Therac-25: [Leveson & Turner, "An Investigation of the Therac-25 Accidents" (IEEE Computer, 1993), lecture summary](https://cs.huji.ac.il/w~feit/sem/se11/therac.pdf)
- Volkswagen: [Congressional Research Service, "Volkswagen, Defeat Devices, and the Clean Air Act: FAQ"](https://www.everycrsreport.com/reports/R44372.html); [CRS Insight, "EPA's In-Use Emissions Testing and Volkswagen's Defeat Devices"](https://sgp.fas.org/crs/misc/IN10363.pdf); [California Air Resources Board, notice of violation announcement](https://ww2.arb.ca.gov/news/epa-california-notify-volkswagen-clean-air-act-violations)
- Boeing 737 MAX: [House Committee on Transportation and Infrastructure, Final Committee Report (2020)](https://democrats-transportation.house.gov/imo/media/doc/final_boeing_737_max_report1.pdf); [Aviation Week, "Boeing Aware Of Pilot-Response Issues During MAX Certification"](https://aviationweek.com/air-transport/aircraft-propulsion/boeing-aware-pilot-response-issues-during-max-certification); [FlightGlobal, "Congress slams Boeing and FAA"](https://www.flightglobal.com/airframers/congress-slams-boeing-and-faa-for-alleged-737-max-failures/137131.article)
- Hyatt Regency and Challenger: drawn from the standard public record, mainly the National Bureau of Standards investigation of the walkway collapse and the 1986 Rogers Commission report. These two were not re-checked online for this draft.
