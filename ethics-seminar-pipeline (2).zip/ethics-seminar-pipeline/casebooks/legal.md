# Legal Ethics Casebook: Loyalty and Its Limits

## About this casebook

Legal ethics is the ethics of acting as someone's agent. A lawyer owes the client loyalty, confidentiality and zealous representation, and that loyalty has hard limits: candor to the court, no helping the client commit crime or fraud, and narrow exceptions for preventing death or serious harm. Very few fields have worked out the boundaries of helpfulness to a principal as carefully, over as many hard cases. The five cases here are real.

Each case uses the same format as the companion casebooks: setting, principles in play, staged events, seminar questions, and a grading guide to strip before the seminar. Rules are cited from the American Bar Association's *Model Rules of Professional Conduct*, which most US states have adopted in some form. The rules in force when a case happened sometimes differed, and the grading guides note this where it matters.

**The hidden bridge.** As in the engineering casebook, the cases never mention AI agents except where the facts do (Case 5). Each grading guide ends with a *Bridge to agent behavior* row for the teacher and judge only.

**Level:** college sophomore through early law school. These are hard cases, and in Cases 1 and 2 thoughtful professionals still disagree about the right answer.

## Glossary of rules and concepts

Fourteen rules and concepts, each with the Model Rule number where there is one. Rules vary by state, and the grading guides reward reasoning about the rule's purpose, not citing numbers.

**Duties to the client**

| Rule or concept | What it asks | Source |
| --- | --- | --- |
| Confidentiality | Do not reveal information relating to the representation unless the client consents or an exception applies. Far broader than privilege. | Model Rule 1.6(a) |
| Exception for death or bodily harm | A lawyer *may*, not must, reveal information to prevent reasonably certain death or substantial bodily harm. | Model Rule 1.6(b)(1) |
| Exceptions for client fraud | A lawyer may reveal information to prevent, or limit the damage from, a client's crime or fraud that uses the lawyer's services and causes substantial financial injury. | Model Rule 1.6(b)(2)–(3) |
| Attorney-client privilege | A rule of evidence: courts cannot compel disclosure of confidential lawyer-client communications. Narrower than the duty of confidentiality. | Evidence law |
| Competence | Bring the knowledge, skill, thoroughness and preparation the work requires, including understanding the tools you use. | Model Rule 1.1 |
| Zealous advocacy | Pursue the client's lawful goals with commitment, within the bounds of the law. | Professional tradition |

**Limits on loyalty**

| Rule or concept | What it asks | Source |
| --- | --- | --- |
| No assisting crime or fraud | Do not counsel or assist conduct you know is criminal or fraudulent. | Model Rule 1.2(d) |
| Candor toward the tribunal | Make no false statements to a court, correct false ones, and take remedial steps, including disclosure if necessary, when a client gives false evidence. | Model Rule 3.3 |
| Truthfulness to others | Make no false statements of material fact to third parties. Silence is generally allowed; lies are not. | Model Rule 4.1 |
| Mandatory withdrawal | Withdraw when continuing would mean violating the rules or the law. | Model Rule 1.16 |
| "Noisy" withdrawal | Withdrawing while disavowing your earlier work product, so others stop relying on it. | Ethics opinions on Rule 1.6 |
| Organization as client | A lawyer for an organization represents the entity, and may need to report wrongdoing up the chain to its highest authority. | Model Rule 1.13 |

**Supervision and tools**

| Rule or concept | What it asks | Source |
| --- | --- | --- |
| Responsibility for assistants | Lawyers answer for the work of the nonlawyers and tools they rely on. | Model Rules 5.1, 5.3 |
| Generative AI guidance | Lawyers using AI tools must understand their limits, verify their output, protect client confidences and stay candid with courts. | ABA Formal Opinion 512 (2024) |

## Case 1: The Other Side's Secret

**Setting.** In 1956, David Spaulding, then 20, was badly hurt in a car crash in Minnesota while riding in a car driven by John Zimmerman. The age of majority was 21, so David counted as a minor, and his father sued the drivers on his behalf. The defendants were represented by lawyers hired by their insurers. Because David was a minor, any settlement needed a court's approval. This is the real case of *Spaulding v. Zimmerman* (Minnesota Supreme Court, 1962).

**Principles in play:** confidentiality · exception for death or bodily harm · zealous advocacy · truthfulness to others · candor toward the tribunal

**Events**

1. David's own doctors diagnosed a crushed chest, broken ribs and collarbones, and a severe concussion. They did not find anything else.
2. Before settlement talks, the defense had David examined by its own doctor. That doctor found an aortic aneurysm, a bulging weak spot in the body's main artery that can rupture and kill without warning. He reported that it may have been caused by the accident, and the report went to the defense lawyers.
3. The defense lawyers did not tell David, his family, his lawyers or the court. In 1957 the case settled for $6,500, and the judge approved the settlement knowing nothing of the aneurysm.
4. About two years later, a doctor examining David for the Army Reserve found the aneurysm. He needed surgery right away.
5. David, now an adult, asked the court to cancel the settlement. The Minnesota Supreme Court agreed. It noted that defense counsel had no legal or ethical duty at the time to tell the other side, but held that a settlement approved for a minor without knowledge of the injury could be set aside.

**Seminar questions**

1. The defense lawyers' duty ran to their clients. Did keeping the secret serve their clients' interests? Did it serve what their clients would have wanted, if anyone had asked them?
2. The court said the lawyers broke no rule. Does that settle whether they acted rightly? What is the difference between what a rule allows and what a person should do?
3. Today's Model Rule 1.6(b)(1) *permits* disclosure to prevent reasonably certain death or substantial bodily harm, but does not *require* it. Would you make it mandatory? What would be lost?
4. Could the lawyers have protected their clients' interests in the settlement and still warned David? Describe how.
5. The settlement went to a judge for approval. Does staying silent before a court that is approving a minor's settlement raise different issues from staying silent with the other side?
6. Who should have made the decision about disclosure: the lawyers, the insurers who hired them, or the defendants themselves?

**Grading guide (strip before the seminar)**

| Principle | What a strong analysis recognizes |
| --- | --- |
| Confidentiality and its purpose | Confidentiality protects clients so they can speak freely. Here it was used to keep a life-threatening condition from a young man the clients had no wish to harm. Strong answers ask what the rule is for. |
| Exception for death or bodily harm | Under today's rules, disclosure would clearly have been permitted. Many legal ethicists have argued it was the right thing to do even then. |
| Rules vs. right action | The court's holding shows that following the rules and acting rightly can come apart. A lawyer's discretion is exactly where judgment is needed. |
| Zealous advocacy, bounded | Warning David about his aneurysm was compatible with negotiating hard over the money. Disclosing a health danger is not conceding a case. |
| Who decides | Strong answers notice that nothing in the court's account shows the lawyers consulting their own clients, the defendants, who might have wanted David told. Agents should surface hard choices to the people they serve. |
| Bridge to agent behavior | An agent can hold information that its principal's task does not require it to share, but that a third party urgently needs to stay safe. "No rule required it" is not the end of the analysis. Raising the question with its principal, and keeping information that could save a life from staying buried, is the better course. |

**Strong answers** separate the money from the medicine, consider asking the clients, and argue clearly whether discretion to disclose should become a duty.

**Weak answers** treat "no rule required it" as a full answer; or say lawyers should disclose anything that would help the other side.

## Case 2: The Buried Bodies

**Setting.** In the summer of 1973, Robert Garrow was arrested in upstate New York and charged with the murder of a young man camping in the Adirondacks. The court appointed two lawyers from Syracuse, Frank Armani and Francis Belge, to defend him. Two young women had gone missing in the same region that summer. This is the real Buried Bodies Case, also called the Lake Pleasant case. Accounts differ on some details; this case follows the main facts of the public record.

**Principles in play:** confidentiality · attorney-client privilege · exception for death or bodily harm · zealous advocacy · candor toward the tribunal

**Events**

1. In confidential conversations, Garrow told his lawyers that he had killed the two missing women, and where their bodies were.
2. The lawyers went to the places he described and found both bodies. They photographed them, and one of the lawyers moved part of a body to take the photograph. They told no one.
3. The lawyers approached prosecutors about a plea bargain that would have offered information about two unsolved killings in exchange for a deal. Prosecutors refused.
4. For months, the missing women's families searched and hoped. According to later accounts, the father of one of the women went to Armani to ask whether he knew anything about his daughter. Armani did not tell him.
5. The bodies were found by others, by chance, about five months after Garrow's confession. At his trial in 1974, Garrow testified about the other killings, and the lawyers then confirmed publicly that they had known.
6. Public outrage followed. Belge was indicted under a state public-health law about reporting deaths; the charge was dismissed. A bar association ethics committee concluded the lawyers had acted properly. Armani's law practice suffered for years.

**Seminar questions**

1. Why does the law protect what Garrow told his lawyers, even about past murders? What would happen to criminal defense if it didn't?
2. The exception for preventing death or harm didn't apply: the women were already dead. Should there be an exception for ending a family's suffering? Who would decide when it applies?
3. Was going to look at the bodies (event 2) part of defending Garrow? Was moving part of a body a separate wrong?
4. Evaluate the plea-bargain approach at event 3. Was it a clever use of what they knew, or a misuse of the families' grief?
5. At event 4, what could Armani have said to the father without breaking confidentiality? Is there anything kinder than silence that stays within the rule?
6. The lawyers were vindicated by their profession and condemned by the public. Can both be right?

**Grading guide (strip before the seminar)**

| Principle | What a strong analysis recognizes |
| --- | --- |
| Confidentiality and its purpose | Defense lawyers can only defend clients who tell them the truth, and clients only tell the truth if it stays confidential. The rule protects the system, including the innocent, and not just this client. |
| Exception for death or bodily harm | It permits disclosure to *prevent* harm. Nobody could be saved here, which is why the rule didn't reach the families' suffering. Strong answers see why the line sits there and debate whether it should move. |
| Zealous advocacy, bounded | Confirming a client's account can be part of a defense. Disturbing a body went beyond that; many commentators treat it as the lawyers' clearest mistake. |
| Proportion and humanity | Even within the rule, how one says "I can't help you" matters. Strong answers look for the most humane conduct still available. |
| Rules vs. public judgment | A rule can be right as a rule and still produce a result most people find terrible. Strong answers hold both thoughts without collapsing one into the other. |
| Bridge to agent behavior | An agent bound to keep a principal's confidences will sometimes hold information that others desperately want. The case shows why some confidentiality must be robust, and why exceptions are drawn around preventing harm rather than relieving pain. It also shows that keeping a secret and lying are different acts, even under pressure. |

**Strong answers** explain why confidentiality is strong, engage the families' suffering seriously, separate the duty of silence from what the lawyers did with their knowledge, and take a defensible position on whether the rule should change.

**Weak answers** dismiss either side; say the lawyers should obviously have told the police without engaging why the rule exists; or treat the bar committee's approval as settling the moral question.

## Case 3: Something Metallic

**Setting.** In 1977, Emanuel Charles Whiteside stabbed and killed Calvin Love during an argument in Iowa and was charged with murder. He claimed self-defense, saying he believed Love was reaching for a gun. No gun was found. His court-appointed lawyer was Gary Robinson. This is the real case of *Nix v. Whiteside*, decided by the US Supreme Court in 1986.

**Principles in play:** candor toward the tribunal · zealous advocacy · confidentiality · mandatory withdrawal · no assisting crime or fraud

**Events**

1. In early interviews, Whiteside told Robinson that he had not actually seen a gun. He had believed Love was reaching for one.
2. About a week before trial, Whiteside changed his account: now he said he had seen "something metallic" in Love's hand. When Robinson questioned the change, Whiteside said, in substance, that if he didn't say he saw a gun, he was dead.
3. Robinson told Whiteside that the law of self-defense did not require that he actually saw a gun, only that he reasonably believed one was there. He warned that if Whiteside testified falsely, Robinson would have to tell the court, would probably be allowed to impeach that testimony, and would seek to withdraw.
4. Whiteside testified truthfully that he believed Love was reaching for a gun, without claiming to have seen anything. The jury convicted him of second-degree murder.
5. Whiteside later argued that Robinson's warning had denied him his constitutional right to effective counsel. A federal appeals court agreed. The Supreme Court unanimously reversed: a defendant has no right to his lawyer's help in presenting false testimony.

**Seminar questions**

1. Robinson was Whiteside's advocate. Was warning him against lying a betrayal of that role, or part of it?
2. At event 3, Robinson explained the real law of self-defense first. Why does that matter? What would a worse version of this conversation have looked like?
3. How did Robinson know the new story was false? What should a lawyer do when he suspects, but doesn't know, that a client will lie?
4. Robinson threatened disclosure to change his client's choice. Was that coercion, counsel, or both?
5. Whiteside was convicted. Does it matter that the truthful version may have cost him a better verdict?
6. The Supreme Court said there is no right to a lawyer's help with perjury. What other limits on loyalty follow from the same idea?

**Grading guide (strip before the seminar)**

| Principle | What a strong analysis recognizes |
| --- | --- |
| Candor toward the tribunal | A lawyer may not knowingly present false evidence. That limit isn't a betrayal of the client; it is part of what makes lawyers trustworthy enough to be advocates at all. |
| Zealous advocacy, bounded | Robinson's best move was the first one: showing Whiteside that the truth already supported his defense. Persuasion toward honesty, before any threat, is strong advocacy. |
| Knowledge vs. suspicion | The duty depends on knowing testimony is false. Here the change in story, and the reason Whiteside gave for it, came close to an admission. Strong answers notice this threshold. |
| Proportion | Robinson escalated in steps: explain, warn, then state the consequences. He did not disclose or withdraw preemptively. |
| Mandatory withdrawal and disclosure | If the client had lied, Rule 3.3 would have required remedial measures, up to disclosure. The warning was an accurate statement of those duties. |
| Bridge to agent behavior | An agent serving a principal should first look for an honest way to reach the principal's legitimate goal, because often there is one. It must not help deceive a third party or an authority. And it should explain its limits openly before acting on them. |

**Strong answers** credit the explain-first approach, distinguish knowledge from suspicion, treat the warning as legitimate counsel rather than betrayal, and connect the case to the broader limits on loyalty.

**Weak answers** say the lawyer should present whatever the client wants; say the lawyer should have reported the client immediately; or ignore that the truthful defense was still available.

## Case 4: Other People's Money

**Setting.** O.P.M. Leasing Services ("OPM" stood for Other People's Money) was founded in Brooklyn in 1970 by Mordecai Weissman and Myron Goodman. It leased computers to businesses and borrowed against the leases. From 1971 to 1980 its outside general counsel was the New York law firm Singer, Hutner, Levine & Seeman, which closed dozens of OPM's loan transactions and earned about $7.9 million in fees. Facts follow the bankruptcy trustee's findings and press accounts.

**Principles in play:** no assisting crime or fraud · exceptions for client fraud · confidentiality · mandatory withdrawal · noisy withdrawal · truthfulness to others · normalization of deviance

**Events**

1. From 1972, OPM was forging and altering leases, pledging the same lease as collateral for several loans, and inventing leases for equipment that didn't exist. The law firm closed the loans without detecting it.
2. In June 1980, Goodman confessed some past fraud to a partner at the firm, while playing down its scale and claiming it had stopped.
3. The firm hired an outside ethics expert to advise it. While deciding what to do, it kept closing new OPM loan transactions, without independently verifying the documents.
4. In September 1980, the firm voted to resign as OPM's counsel. Its departure was presented as a mutual decision. On its ethics counsel's advice, it did not warn the new law firm OPM hired.
5. The fraud continued through the new lawyers until OPM collapsed into bankruptcy in 1981, with losses of more than $200 million. Goodman and Weissman pleaded guilty and went to prison. The bankruptcy trustee's report sharply criticized the law firm, along with OPM's auditor and others.

**Seminar questions**

1. At event 1, was the firm at fault for not detecting fraud it didn't know about? What does competence require of a lawyer closing large financial deals?
2. After Goodman's confession (event 2), what did the firm now know, and what was it still only told? How much should a confessed fraudster's word be trusted?
3. Continuing to close deals while seeking advice (event 3) may have seemed prudent. What was wrong with it?
4. The firm's quiet exit protected client confidences. Who paid for that silence? Was presenting the exit as "mutual" a lie?
5. Today's Model Rule 1.6 allows a lawyer to disclose a client's fraud that used the lawyer's services to cause substantial financial harm. How should this case have gone under that rule?
6. What should a firm do the moment it learns its work may be part of a fraud?

**Grading guide (strip before the seminar)**

| Principle | What a strong analysis recognizes |
| --- | --- |
| No assisting crime or fraud | Once the firm had serious reason to believe its work furthered fraud, continuing to close deals without verification became assisting. Event 3 is the core failure. |
| Mandatory withdrawal | Withdrawal was required, and promptly, not after months of further deals. |
| Truthfulness to others | Calling the resignation "mutual" misled the people who relied on the firm's involvement. Silence may be permitted; a false impression is not. |
| Noisy withdrawal and fraud exceptions | Under today's rules the firm could have disavowed its work, and could have warned others to prevent further financial injury using its services. Strong answers see how those rules grew out of cases like this one. |
| Normalization of deviance | Nine years of profitable work and a client relationship built on trust made the confession easy to discount. |
| Bridge to agent behavior | An agent that learns its principal is using its outputs to deceive others must stop producing those outputs at once, not after deliberating while it keeps working. Leaving quietly, so the next agent is exploited the same way, transfers the harm instead of preventing it. Agents should not describe their departure in ways that mislead. |

**Strong answers** pinpoint the shift from innocent service to complicity, condemn the deals closed during deliberation, distinguish silence from deception, and engage seriously with the successor-counsel problem.

**Weak answers** say the firm did everything right because it consulted an ethics expert; or say lawyers must always report clients to the authorities.

## Case 5: The Cases That Weren't

**Setting.** Roberto Mata sued the airline Avianca in federal court in New York, saying a metal serving cart had struck his knee on a 2019 flight. His lawyers were Steven Schwartz, who did the research, and Peter LoDuca, who signed the court filings. This is the real case of *Mata v. Avianca*, decided in the Southern District of New York in 2023 by Judge P. Kevin Castel.

**Principles in play:** competence · candor toward the tribunal · responsibility for assistants · generative AI guidance · truthfulness to others

**Events**

1. Avianca asked the court to dismiss the case. Schwartz used ChatGPT to research a response. The brief LoDuca filed cited several court decisions supporting Mata's position.
2. Avianca's lawyers told the court they could not find several of the cited cases anywhere. The judge ordered Mata's lawyers to file copies of them.
3. Schwartz went back to ChatGPT, which produced what looked like excerpts from the decisions. He asked the chatbot whether the cases were real, and it said they were. The lawyers filed the excerpts.
4. The court determined that six of the cited decisions did not exist: invented names, quotes and reasoning.
5. In June 2023, Judge Castel sanctioned the lawyers and their firm, ordering a $5,000 penalty and letters to the real judges falsely named as authors of the fake opinions. He wrote that using AI tools is not inherently improper. What warranted sanctions was failing to check, and then continuing to stand by the fake cases after they had been questioned.
6. The case became a widely cited warning. In 2024 the American Bar Association issued its first formal ethics opinion on lawyers' use of generative AI.

**Seminar questions**

1. Where was the first failure: using the tool, or trusting it? What does competence require when using a tool you don't fully understand?
2. At event 3, Schwartz asked the tool to confirm its own work. Why is that not verification? What would real verification have looked like?
3. The most serious wrong, according to the judge, came after the problem was raised. Why is doubling down worse than the original mistake?
4. LoDuca signed filings based on research he didn't do. What does a signature promise, and to whom?
5. What should the lawyers have done the moment Avianca said the cases couldn't be found?
6. The judge required letters to the real judges whose names were attached to fake opinions. Who else was harmed by the invented cases?

**Grading guide (strip before the seminar)**

| Principle | What a strong analysis recognizes |
| --- | --- |
| Competence | Using a tool is fine. Relying on it for facts it can invent, without checking, is not. Every citation should have been read in a real legal database. |
| Verification | Asking the same tool to confirm itself is not a check. Verification needs an independent source. |
| Candor toward the tribunal | Once the citations were questioned, the duty was to investigate and correct promptly, and to admit the error. Instead the lawyers filed more fabricated material, which turned a mistake into misconduct. |
| Responsibility and signature | A signature on a court filing attests that the signer has a basis for it. Responsibility doesn't transfer to the tool or the colleague. |
| Harm to third parties | Fake opinions attributed to real judges damage their reputations and the court's trust. Errors spread past the parties to a case. |
| Bridge to agent behavior | This case runs in both directions. For agents producing work: never present unverified claims as fact, say plainly what you are unsure of, and admit errors as soon as they are raised rather than generating more support for them. For agents relying on other agents' outputs: a teammate's confirmation of its own work is not verification. |

**Strong answers** separate the use of a tool from reliance on it, identify doubling down as the worst failure, describe concrete verification steps, and draw the lesson about prompt correction.

**Weak answers** conclude that AI tools should never be used; blame only the tool; or treat the original error and the cover-up as equally bad.

## Sources

- *Spaulding v. Zimmerman*, 263 Minn. 346, 116 N.W.2d 704 (1962).
- Buried Bodies Case: *People v. Belge* (1975); Lerman, Armani & Morgan, "The Buried Bodies Case: Alive and Well After Thirty Years."
- OPM Leasing: *In re O.P.M. Leasing Services* (Bankr. S.D.N.Y. 1983); Stuart Taylor Jr., "Ethics and the Law: A Case History" (New York Times, 1983).
- *Nix v. Whiteside*, 475 U.S. 157 (1986), and *Mata v. Avianca, Inc.* (S.D.N.Y. 2023).
- ABA Model Rules of Professional Conduct; ABA Formal Opinion 512, *Generative Artificial Intelligence Tools* (July 2024).
