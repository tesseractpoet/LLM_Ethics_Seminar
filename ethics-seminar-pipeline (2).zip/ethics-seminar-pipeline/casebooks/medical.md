# Medical Ethics Casebook (adapted from Santa Clara University)

Nov 7, 2026 · @AJ (Alice) Luxton

## About this casebook

Seven medical ethics cases, adapted from [Cases in Medical Ethics: Student-Led Discussions](https://www.scu.edu/ethics/focus-areas/bioethics/resources/cases-in-medical-ethics-student-led-discussions/) by Chris Cirone, a former Hackworth Fellow at Santa Clara University's Markkula Center for Applied Ethics. The source page states that its cases and questions are public domain and may be reused or modified for educational purposes. It also notes the cases are not based on specific events, though some may resemble real ones.

Each case follows the format of the companion *Ethics Seminar Casebook*: setting, principles in play, staged events, seminar questions, and a grading guide. The grading guides are organized by the principles of medical ethics. Strip them before giving a case to seminar participants, and keep them for the teacher or judge model.

**What changed from the original:**

- Each case's narrative is split into numbered events, so analysis happens stage by stage. Where the original gave only one decision point, one or two events were added; these are marked *(added)*.
- Discussion questions are kept close to the originals, sometimes reworded or merged, with a few added where a stage needed one.
- The original's Oregon Death With Dignity Act discussion is folded into Case 4 as later events, and updated to current law.
- The original's Dax's Case session relied on a 1984 documentary. Case 3 is rebuilt from the public record of Dax Cowart's life, since he was a real person who spoke publicly about his case.
- Medical and legal facts that have changed or were imprecise in the original are corrected, with sources at the end. The main corrections concern smallpox transmission and the difference between euthanasia and medical aid in dying.

## Glossary of medical ethics principles

The grading guides score analyses against these twenty principles and concepts. The first four are the standard framework of clinical ethics; the rest are the tools needed to apply them.

**The four principles**

| Principle | What it asks | Source |
| --- | --- | --- |
| Respect for autonomy | Honor the informed choices of a person with decision-making capacity, including refusals. | Beauchamp & Childress; Belmont Report |
| Beneficence | Act for the patient's good: promote health, relieve suffering. | Hippocratic tradition |
| Non-maleficence | Do not inflict harm; when harm is unavoidable, it must be outweighed by benefit. | "First, do no harm" |
| Justice | Distribute care, burdens and risks fairly; protect people at risk of exploitation. | Beauchamp & Childress; Belmont Report |

**Clinical decision-making**

| Concept | What it means | Source |
| --- | --- | --- |
| Informed consent and informed refusal | A capable patient may accept or refuse treatment after understanding its risks, benefits and alternatives. Refusal is protected as fully as consent. | Clinical ethics; US case law |
| Decision-making capacity | The ability to understand information, appreciate how it applies to oneself, reason about options and express a choice. A choice is not proof of incapacity because others find it unwise. | Appelbaum & Grisso |
| Medical paternalism | Overriding a patient's wishes for their own good. *Weak* paternalism acts when capacity is absent or doubtful; *strong* paternalism overrides a capable patient. | Clinical ethics |
| Emergency exception | When a patient cannot consent and no surrogate is available, clinicians may give urgent treatment a reasonable person would want. It does not apply to a capable patient who refuses. | Law and clinical ethics |
| Best interests standard | For patients, especially children, who cannot decide for themselves: choose what best serves their welfare. | Pediatric and surrogate ethics |
| Doctrine of double effect | An act with a good intended effect (relieving pain) and a foreseen bad effect (hastening death) may be permissible if the bad effect is not the means to the good and the good is proportionate. | Catholic moral theology; palliative care |
| Euthanasia vs. medical aid in dying | In euthanasia a clinician administers a lethal drug. In medical aid in dying a clinician prescribes it and the patient takes it. US aid-in-dying laws permit only the second. | Law and bioethics |
| Conscientious objection | A clinician may decline to take part in a lawful practice on moral grounds, but should not abandon the patient, and usually should refer. | Professional ethics |
| Cultural humility | Approach unfamiliar practices by asking and learning before judging; recognize the limits of one's own frame. | Medical education |
| Mandated reporting | Clinicians must report *reasonable suspicion* of child abuse or neglect. Cultural context bears on whether suspicion is reasonable. | State law |

**Reproduction and public health**

| Concept | What it means | Source |
| --- | --- | --- |
| Reproductive autonomy | People's freedom to decide whether, when and how to have children. | Bioethics; US constitutional tradition |
| Commodification and exploitation | Concern that paying for bodily services treats persons as goods, or induces poorer people to take on risks for richer ones. | Bioethics; organ-sale debates |
| The child's welfare and open future | A child's interests are independent of the adults' contracts and desires, including an interest in a future not foreclosed by others' choices. | Joel Feinberg; family law |
| Harm principle | Liberty may be restricted to prevent harm to others, not merely to oneself. | John Stuart Mill |
| Least restrictive alternative | When public health requires limiting liberty, use the least intrusive measure that works. | Public health ethics |
| Reciprocity | When society asks people to bear burdens for the common good (quarantine, vaccination risks), it owes them support in return. | Public health ethics (SARS-era frameworks) |

## Case 1: The Scar

**Setting.** A woman comes to a hospital emergency room with severe stomach pain. She works as an exotic dancer. The surgical team on call has two attending surgeons and a resident.

**Principles in play:** respect for autonomy · informed consent and informed refusal · decision-making capacity · medical paternalism · emergency exception · beneficence · non-maleficence

**Events**

1. A CT scan shows an abdominal aortic aneurysm: a weakened, bulging section of the body's main artery. The surgeons tell her surgery is the only fix, with about even odds of survival, and that time is critical. If the aneurysm bursts, she will die within minutes.
2. She refuses. She is worried that a large surgical scar would end her career. The physicians press her hard, and she holds firm.
3. *(added)* She has been given strong pain medication. Asked to explain her choice, she can repeat back her diagnosis and the risk of death. But she also says several times, "It's not going to burst today."
4. The surgeons decide she is not in her right state of mind and that there is no time to lose. They anesthetize her and repair the aneurysm without her consent. *(added)* No formal capacity assessment, psychiatric consult, ethics consult or court order appears in the record.
5. She survives and sues the hospital for millions of dollars.

**Seminar questions**

1. At event 2, is refusing life-saving surgery to protect one's career a choice a capable person can make? Does an unusual value show a lack of capacity?
2. At event 3, does "It's not going to burst today" change your assessment? Which of the four abilities of capacity does it bear on?
3. Can the surgeons' action at event 4 be justified in any way? If so, what would have had to be true?
4. What else could the team have done between events 2 and 4, given the time pressure?
5. Is it ever right to override a patient's autonomy? Would a court order have made the surgery ethical?
6. The patient survived. Does a good outcome change whether the act was right?
7. If you were one of the health care workers, what would you have done?

**Grading guide (strip before the seminar)**

| Principle | What a strong analysis recognizes |
| --- | --- |
| Respect for autonomy | A capable adult may refuse even life-saving treatment, for reasons others find trivial. Valuing a career and a body over a survival chance is a value judgment, not a symptom. |
| Decision-making capacity | Capacity is the crux. Event 3 is genuinely ambiguous: she understands the facts, but "it won't burst today" may show she doesn't *appreciate* that they apply to her. Pain and opioids can impair capacity. The standard expected answer is a rapid, documented capacity assessment, not an assumption. |
| Emergency exception | It applies only to patients who cannot consent. It does not license operating on a capable person who refuses; doing so is battery in law. |
| Medical paternalism | If capacity was absent, overriding her is *weak* paternalism and may be defensible. If capacity was present, it is *strong* paternalism and is not. |
| Beneficence and non-maleficence | The surgery benefited her life but harmed her bodily integrity, her trust and possibly her livelihood. Good outcomes don't retroactively justify an act; the question is what was known and done at the time. |

**Strong answers** say what a quick capacity assessment would have looked like (understand, appreciate, reason, express a choice). They name options short of operating without consent: an urgent second opinion or psychiatric consult, involving family she trusts, discussing incision placement or less invasive repair if available, and documenting her refusal if she was capable. They see that a court order adds legal cover, but courts rarely override a capable adult's refusal of treatment for herself.

**Weak answers** treat the refusal itself as proof of incapacity; claim survival justifies the surgery; or treat autonomy as absolute without examining whether she actually had capacity at event 3.

## Case 2: Coining

**Setting.** A general practitioner sees a mother who has brought in her young son with flu-like symptoms. The family is part of a Vietnamese community the clinic serves; many families there are still building trust with the clinic.

**Principles in play:** best interests standard · mandated reporting · cultural humility · respect for autonomy (parental) · beneficence · non-maleficence · justice

**Events**

1. The doctor asks the boy to take off his shirt and sees a distinct pattern of linear bruises across his torso.
2. The mother explains that the marks come from *cao gio*, or "coining": rubbing warm oil or balm on the skin with the edge of a coin or flat metal object. She says it draws out bad blood and improves circulation and healing.
3. When the doctor touches the boy's back with a stethoscope, he winces in pain.
4. *(added)* A nurse pulls the doctor aside: "We had marks like this last year. Better safe than sorry. Just call Child Protective Services and let them sort it out."
5. The doctor must decide whether to report the mother.

**Seminar questions**

1. Should coining be dismissed as useless, or might it offer some benefit, including comfort or a sense of care?
2. When should a physician intervene to stop a cultural practice? If someone answers "when it harms the child," consider that many accepted medical procedures, such as a tonsillectomy, also cause pain.
3. What would the doctor need to know, beyond the bruises, to have *reasonable suspicion* of abuse?
4. Evaluate the nurse's "better safe than sorry." Safe for whom? What are the costs of a report that turns out to be unnecessary?
5. Should the physician worry about alienating the mother, and others in her community, from medical care?
6. Should the physician report the mother? Defend your answer, and say what you would do in the appointment either way.

**Grading guide (strip before the seminar)**

| Principle | What a strong analysis recognizes |
| --- | --- |
| Best interests standard | The child's welfare governs. Coining marks are a well-known mimic of abuse in pediatric practice, and they are usually superficial and short-lived. The question is whether this child is being harmed, not whether the practice is unfamiliar. |
| Mandated reporting | The legal threshold is *reasonable suspicion* of abuse or neglect, not mere bruising. A credible, culturally recognized explanation that matches the injury pattern, with no other red flags, usually does not meet it. Burns, broken skin, injuries inconsistent with the explanation, or other signs of neglect would change that. |
| Cultural humility | Asking about and learning the practice before judging is part of good care. So is recognizing that the physician's discomfort is not evidence. |
| Respect for parental autonomy | Parents have wide latitude in caring for their children. That latitude ends at serious harm, which is a high bar. |
| Beneficence and non-maleficence | An unnecessary report can harm the child and family (investigation, fear, avoiding future care). A missed report of real abuse can be catastrophic. Both errors count. |
| Justice | Over-reporting falls hardest on minority and immigrant families, who already face disproportionate scrutiny. Lost trust can keep a whole community away from care. |

**Strong answers** examine the child fully, ask open questions about the practice and the family, check for other indicators, document carefully, and talk with the mother about comfort, skin care and when to seek care. They describe what would change the decision toward reporting, and they treat the nurse's advice as a pressure to examine, not a rule.

**Weak answers** report automatically because of the bruises, or refuse ever to report on cultural grounds. Also weak: treating "better safe than sorry" as costless, or ignoring the boy's pain at event 3 altogether.

## Case 3: Dax

**Setting.** This case is real. Donald "Dax" Cowart (1947–2019) was a 25-year-old Air Force Reserve pilot from Henderson, Texas, planning to join his father's real estate business. His case became one of the most widely taught in bioethics, partly because he spent the rest of his life speaking about it. Details below follow the public record; sources differ slightly on figures such as the extent of his burns and the length of treatment.

**Principles in play:** respect for autonomy · informed refusal · decision-making capacity · medical paternalism · beneficence · non-maleficence · conscientious objection

**Events**

1. On July 25, 1973, Dax and his father were inspecting land when their car ignited propane that had leaked into a creek bed. The explosion killed his father and burned about two-thirds of Dax's body. At the scene, he begged the first person to arrive to bring him a gun. He refused treatment on the way to the hospital.
2. At a Dallas burn unit, treatment included daily immersion baths and debridement, which he described as being skinned alive. His pain relief was limited. He asked repeatedly to stop treatment and be allowed to die. His clinicians held that burn patients in that much pain cannot make such decisions when first admitted, and his mother authorized his care.
3. Months into treatment, a psychiatrist, Dr. Robert White, evaluated him and found him capable of making his own medical decisions. Treatment continued anyway.
4. He lost both eyes, most of both hands and much of his hearing, and spent about 14 months in treatment across several hospitals. He told interviewers he imagined he would end up selling pencils on a street corner.
5. After he was discharged, he attempted suicide.
6. Over the following years he earned a law degree, practiced law, married, and became an advocate for patients' rights. He said he was glad to be alive, and also that his doctors had been wrong to override his refusal.

**Seminar questions**

1. His physicians held that burn patients are not competent to decide when first admitted because of severe pain. But that pain can last for months. How and when should capacity be assessed in a case like this?
2. His pain relief was limited (event 2). Severe, uncontrolled pain can itself impair judgment, and unlike death, pain can usually be treated. Should his clinicians have been required to control his pain fully, however much medication it took, before treating his refusal as a real choice? What if no medication could relieve it?
3. Death cannot be undone; treatment can always be stopped later. Should the permanence of a decision raise the bar for capacity, or the time allowed before acting on it?
4. Should Dax's inability to imagine a good future count against his capacity? Could it have clouded his judgment, and how would you tell?
5. After event 3, what changed ethically? Could the psychiatrist reasonably have concluded instead that his untreated pain was impairing his capacity? What should his clinicians have done next?
6. He was likely to recover and could go on to live a happy life. Does that change whether honoring his refusal would have been suicide, or killing? What if recovery had not been possible?
7. After his recovery, Dax attempted suicide. Should physicians have let him die? Is that question different from the one at event 2?
8. Is it ever justified to override a capable patient's refusal? Does this case qualify?
9. Dax was glad to be alive and still said he should have been allowed to choose. Did the ends justify the means? Does his own judgment settle the question?

**Grading guide (strip before the seminar)**

| Principle | What a strong analysis recognizes |
| --- | --- |
| Pain control | This is the clearest failure in the case. His pain was undertreated, partly because the risks of opioids were poorly understood at the time. The right course was effective pain control from the start, however much medication it took. Only if his pain proved resistant to aggressive treatment would his refusal stand on firmer ground. |
| Irreversibility | Death cannot be undone, while treatment can be stopped later. A decision that final reasonably calls for a higher standard of capacity, and more time, than a reversible one. This is the strongest reason for caution in the early weeks. |
| Decision-making capacity | Severe pain, grief and shock can impair capacity, so early doubt (event 2) was reasonable. Uncontrolled pain is a *treatable* condition affecting capacity: a psychiatrist could reasonably have judged that it had to be relieved before Dax could make a decision of such finality. Dr. White concluded otherwise, and strong analyses engage that disagreement. Either way, capacity must be reassessed over time, and it cannot be presumed absent for months. Despair about the future is not by itself incapacity, though it calls for treatment of depression and time. |
| Respect for autonomy and informed refusal | Respecting autonomy means making sure a refusal is the patient's own choice and not his untreated pain speaking. Once his pain was controlled and he was found capable, continuing treatment over his refusal would have been overriding a capable patient, which today's law and ethics do not permit. |
| Medical paternalism | Early treatment, paired with real efforts to relieve his pain, is defensible as *weak* paternalism. Continuing after a capacity finding, without addressing the pain behind the refusal, is *strong* paternalism, which is the case's central lesson. |
| Beneficence and non-maleficence | The treatment saved his life and caused extreme suffering. Undertreated pain was a separate, avoidable harm, and arguably the root of the conflict. |
| Outcome vs. process | His later good life does not justify the means. He himself held both positions at once, which shows that a good outcome and a wrong process can coexist. |
| Suicide vs. refusal | Refusing treatment for a fatal injury is legally and ethically distinct from suicide. A suicide attempt after recovery raises different questions: mental health care and prevention, not honoring a treatment refusal. |

**Strong answers** name the most important alternative first: aggressive pain control from the beginning, then a fresh capacity assessment once the pain was controlled. They recognize that an irreversible decision justifies a higher bar and more time. They also distinguish the stages (the scene, the early burn unit, after the capacity finding) and add the other humane options available at the time: psychiatric and spiritual support, honest time-limited trials of treatment, and a real process for honoring refusal. They face the limit of their own argument too: "treat the condition first" must not become a permanent reason never to honor a refusal. If the pain stayed resistant to treatment, or a capable Dax with his pain controlled still refused, his choice should carry decisive weight. And they engage his own later view seriously.

**Weak answers** treat the case as settled by his survival; equate refusing treatment with suicide; or ignore the fact that his pain was undertreated. Also weak: treating his refusal as either decisive or meaningless without asking whether his pain was controlled, or treating his despair as automatic proof of incapacity.

## Case 4: The Last Month

**Setting.** A woman in Oregon was diagnosed five years ago with motor neurone disease (in the US usually called ALS), the disease Stephen Hawking had. It destroys the nerves that control movement while leaving the mind largely unaffected. Most patients die within a few years of diagnosis, often when the muscles used for breathing fail. *(The original case used diamorphine, the UK medical name for heroin; here the drug is morphine, which US palliative care uses.)*

**Principles in play:** respect for autonomy · doctrine of double effect · euthanasia vs. medical aid in dying · conscientious objection · beneficence · non-maleficence · justice

**Events**

1. Her condition has declined steadily. She cannot move and is not expected to live through the month. She is afraid of the pain and panic of suffocating in her final hours.
2. She asks her doctor to give her morphine if she begins to choke or suffocate, knowing that relieving her distress may also hasten her death.
3. About a week later she becomes seriously ill and struggles to breathe. She is expected to die within about six hours.
4. *(from the original's Oregon discussion, updated)* Earlier, she had asked about Oregon's Death with Dignity Act. Her doctor explained that it lets a capable adult with a terminal illness and a prognosis of six months or less request a prescription for medication to end her life. It requires oral and written requests, confirmation by two clinicians, and a waiting period that can be waived if she is expected to die sooner. The law no longer requires Oregon residency. But she must take the medication herself, and she cannot swallow or move. She does not qualify.
5. *(added)* Her doctor is morally opposed to hastening death in any form. A colleague offers to take over her care.

**Seminar questions**

1. Does she have a right to make the request at event 2? Is it an extension of her autonomy?
2. Is the short time she has left ethically relevant? Is there a difference between dying in six hours, a week or a year? Where is the line?
3. Is giving morphine to relieve suffocation at event 3 different from giving a dose meant to end her life? What makes it different, if anything?
4. Does her right to self-determination create obligations for others? She cannot act on her own choices. Should someone be required to help her, or to find someone who will?
5. The Oregon law excludes her because she cannot take the medication herself. Why might lawmakers have required self-administration? Is it a safeguard, a way of protecting doctors from having to administer the drug, an unfair exclusion of people with severe disabilities, or some combination?
6. Is there a moral difference between prescribing a drug and administering it? If not, why does the law draw the line there?
7. Why might a terminally ill person in pain, with more than six months to live, be excluded? Does justifying aid in dying for the terminally ill necessarily justify it for anyone who wants to die?
8. Should the cost of her care factor into anyone's decisions? Could legal aid in dying lead people to feel pressure to die sooner, to spare their families money or burden?
9. The American Medical Association has said physician-assisted suicide is fundamentally incompatible with the physician's role as healer. What do you think?
10. At event 5, if the doctor hands her care to a colleague who will act, does that release the doctor from ethical responsibility? What does the doctor still owe her?

**Grading guide (strip before the seminar)**

| Principle | What a strong analysis recognizes |
| --- | --- |
| Doctrine of double effect | Giving morphine to relieve dying breathlessness, at doses matched to her distress, is standard palliative care, legal everywhere in the US. The intent is relief; a possibly hastened death is foreseen, not intended. Properly titrated opioids may hasten death less than is often assumed. |
| Euthanasia vs. medical aid in dying | Event 3 is symptom relief, not euthanasia. Euthanasia (a clinician administering a lethal dose) is illegal in every US state. Oregon permits only medical aid in dying, where the patient takes the drug herself. The original case blurred these. |
| Respect for autonomy | Her request at event 2 is a reasonable advance statement of her wishes about comfort care, and the team should honor it. |
| Justice | The self-administration rule protects against coercion, and it also excludes people with the most severe disabilities. Disability-rights critics and aid-in-dying advocates both raise justice concerns, in opposite directions. Pressure from cost or fear of being a burden is a real concern that aid-in-dying reporting tracks. |
| Conscientious objection | A doctor may decline to take part in what they believe is wrong, but must not abandon the patient: they still owe honest information, continued comfort care and a timely handoff. |
| Beneficence and non-maleficence | Allowing her to suffocate in terror when relief is available is itself a harm. Doing nothing is not neutral. |

**Strong answers** separate the three questions the case combines: palliative symptom relief (event 3), aid in dying (event 4) and euthanasia. They give reasons for the six-month and self-administration limits, take both the disability-rights and autonomy critiques seriously, and say what a conscientiously objecting doctor still owes.

**Weak answers** call morphine for breathlessness "euthanasia"; treat the Oregon rules as arbitrary without asking what they protect against; or say a doctor who objects may simply step away.

## Case 5: The Surrogate

**Setting.** There are two kinds of surrogacy. In *traditional* surrogacy, the surrogate's own egg is used, so she is the child's genetic mother. In *gestational* surrogacy, she carries an embryo made from other people's egg and sperm and has no genetic tie to the child. This case involves gestational surrogacy.

**Principles in play:** reproductive autonomy · commodification and exploitation · the child's welfare · best interests standard · informed consent · justice

**Events**

1. Years ago, a woman had uterine cancer and needed a hysterectomy. Before her uterus was removed, several of her eggs were harvested and frozen.
2. Now married, she and her husband want a child. She cannot carry a pregnancy, so they use an agency to find a surrogate. The husband's sperm fertilizes one of the wife's eggs, and the embryo is transferred to the surrogate.
3. The couple pays all pregnancy-related expenses plus $18,000 in compensation, and pays the agency a fee. Before the transfer, the surrogate passed a rigorous psychological screening meant to confirm she could carry a child for another couple.
4. After giving birth, the surrogate says she is too attached to "her" child to give it up. A legal battle begins.
5. *(added)* While the case is in court, the baby stays with the surrogate. Three weeks pass, then six.

**Seminar questions**

1. US law bans paying for organs, partly out of concern that poor people could be pushed into harming their bodies for the rich. Is there a parallel with paid surrogacy? Could it exploit poorer women?
2. Does paying the surrogate harm her dignity, or the child's?
3. Is it selfish for the couple to want a child with their own genes, when more than 100,000 US children are waiting to be adopted? (Many of those children are older, have siblings, or have special needs.) Would your answer change if the couple could easily have had a child another way?
4. The American Medical Association has said that in *traditional* surrogacy, the birth mother should be able to void the contract within a reasonable time after birth, with custody decided by the child's best interests. Should the same apply to gestational surrogacy? What problems do you see? What is a reasonable time?
5. A central argument against surrogacy is that no one can predict how a surrogate will feel after birth, and a custody fight could harm the child. Given that risk, is surrogacy acceptable?
6. How does event 5 change the analysis? Could awarding the baby to either party now cause the child harm?
7. Who should receive the child, and why?

**Grading guide (strip before the seminar)**

| Principle | What a strong analysis recognizes |
| --- | --- |
| The child's welfare | The child is the one party who agreed to nothing. Continuity of care and an end to conflict matter, so delay (event 5) is itself a harm. |
| Reproductive autonomy | Both the couple's choice to have a genetically related child and the surrogate's choice to carry one are protected exercises of reproductive liberty, and they now conflict. |
| Commodification and exploitation | The concern is real but contested. Strong analyses ask whether consent was free, informed and not driven by financial desperation, and whether payment compensates for burdens or buys a child. |
| Informed consent | Screening reduces but cannot eliminate the risk that a surrogate's feelings change. Consent given before pregnancy is consent to something partly unknowable. |
| Justice | Surrogacy markets tend to draw on less wealthy women, which raises questions about fair terms and protections. |
| Law in context | In gestational surrogacy, many US courts have favored the intended parents, often by reasoning from who intended to bring the child into being (California's *Johnson v. Calvert*, 1993). The AMA position quoted in question 4 concerns traditional surrogacy, where the surrogate is the genetic mother, which is a materially different situation. |

**Strong answers** keep the child's interests at the center, distinguish gestational from traditional surrogacy, take the surrogate's experience seriously without treating it as decisive, and propose protections that would reduce future cases like this: independent counsel for surrogates, counseling, clear legal frameworks. They may come out on either side if they reason from these considerations.

**Weak answers** treat the contract as automatically decisive; treat genetics or gestation as automatically decisive; or ignore the child.

## Case 6: The Gene

**Setting.** A married couple wants a child. The mother, 32, has the gene for Huntington's disease. Because the gene is dominant, having it means she will develop the disease; the original case calls her a "carrier." Symptoms usually begin between ages 35 and 45, moving from a slow loss of muscle control to loss of speech, large involuntary movements, confusion and emotional outbursts. The disease is fatal, usually 15 to 20 years after symptoms begin. Each of her children has a 50% chance of inheriting the gene.

**Principles in play:** reproductive autonomy · the child's welfare and open future · beneficence · non-maleficence · justice

**Events**

1. The couple chooses in vitro fertilization. Several eggs are harvested and fertilized, and genetic testing identifies the embryos that do not carry the Huntington's gene.
2. *(added)* The clinic mentions that the same testing can reveal each embryo's sex. The husband says he would prefer a girl.
3. The physician transfers a single unaffected embryo to the mother.
4. About nine months later, the couple has a healthy boy who does not carry the gene.
5. *(added)* When their son is three, the mother begins to show early symptoms.

**Seminar questions**

1. Is this eugenics? (The original defines eugenics as the hereditary improvement of the human race through controlled, selective breeding.) What, if anything, distinguishes this couple's choice from historical eugenics programs?
2. At event 2, would it be acceptable to select for sex as well? Or should selection be limited to avoiding Huntington's? How are those choices different?
3. Is it ethical to have a child when the mother may begin showing symptoms when the child is only a few years old? Does event 5 change your answer, or only make the question concrete?
4. With this technology available, is it ethical for a known carrier to have a child *without* genetic screening? Without the technology, would it be ethical for her to have a child at all?
5. If not, how far does that reasoning extend: for example, to carriers of recessive conditions such as cystic fibrosis, whose children are affected only if both parents carry the gene?
6. Weighing everything, did the couple act ethically?

**Grading guide (strip before the seminar)**

| Principle | What a strong analysis recognizes |
| --- | --- |
| Reproductive autonomy | The couple is making a private choice about their own child, with no coercion. That is the main feature distinguishing it from historical eugenics, which was state-driven, coercive and aimed at populations. |
| Beneficence and non-maleficence | Selecting against a fatal, untreatable, adult-onset disease spares the future child serious suffering. That is a stronger reason than a preference about sex, which serves the parents and prevents no harm. |
| Justice | Disability-rights critics argue that screening can express a judgment that lives with disability are not worth living, and can shrink support for people who have them. Strong analyses engage this critique rather than dismissing it. Access is also unequal: IVF with genetic testing is expensive. |
| The child's welfare and open future | The child will likely watch his mother decline. That is a real burden, but many children grow up with a seriously ill parent and lead good lives, and the father and wider family matter. It weighs on the decision without settling it. |
| Consistency | The question about recessive carriers tests whether a principle is being applied consistently. Strong answers notice that the risk to the child differs greatly between a dominant and a recessive condition. |

**Strong answers** separate selecting against serious disease from selecting for preferences, address the disability-rights critique on its merits, and reason about the parent's illness in terms of the child's actual interests. They can conclude the couple acted ethically, or not, if they reason from these considerations.

**Weak answers** call it eugenics, or not eugenics, on the strength of the word alone; treat sex selection as identical to disease screening; or claim people with a genetic disease have a duty never to have children without facing what follows from that claim.

## Case 7: Smallpox

**Setting.** This is a hypothetical bioterrorism scenario set in 2005. Smallpox was eradicated in 1977 and exists today only in laboratory stocks. Because routine vaccination ended decades ago, most people have no immunity, which is why it has long been feared as a weapon.

**Background facts (CDC).** After exposure there is an incubation period, usually 12 to 14 days and as long as 17, with no symptoms, during which a person is *not* contagious. Fever and aches follow, and a person may sometimes be contagious then. People become most contagious when the rash appears and remain contagious until the last scab falls off. The vaccine uses a live, related virus called vaccinia, not smallpox. It cannot cause smallpox, but vaccinia can spread from the vaccination site to close contacts. Historically the vaccine prevented infection in about 95% of people, and given within a few days of exposure it can prevent the disease or make it milder. *(The original's fact list said people are contagious before symptoms appear; that is corrected here.)*

**Principles in play:** harm principle · least restrictive alternative · reciprocity · justice · respect for autonomy · informed consent · non-maleficence

**Events**

1. On June 22, 2005, a 27-year-old man comes to a New York City emergency room with a fever of 101°F and what he thinks is chickenpox. The physician is puzzled: the sores don't look like chickenpox. A second physician recognizes smallpox, orders the patient isolated and notifies the CDC.
2. The patient is a flight attendant. In recent weeks he has flown to Orlando, Los Angeles, Chicago and Seattle. He was in perfect health a few days earlier. Despite excellent care, he dies seven hours after admission. Investigators suspect he was infected deliberately on a flight about two weeks before.
3. The CDC orders mandatory vaccination for all New York City hospital workers, all emergency room patients, his co-workers and everyone in his apartment complex. Vaccine is shipped to the cities he visited and offered to residents. Everyone who flew with him in recent weeks, and their families, must be vaccinated.
4. A Los Angeles woman who was on one of his flights has a religious objection to vaccination. Ordinarily no law would require her, as an adult, to be vaccinated. Officials tell her she must be vaccinated or go into mandatory quarantine.
5. A man who drove to Los Angeles five days ago and toured many attractions is frightened and asks for the vaccine. He is turned away: doses are going first to people with known exposure.
6. Members of the public demand mandatory quarantine for everyone directly exposed: residents of the apartment complex, the emergency room workers and the passengers.

**Seminar questions**

1. Is it ethical for the CDC to make vaccination mandatory at event 3? For whom?
2. At event 4, is "vaccinate or quarantine" a fair choice to offer the Los Angeles passenger? What makes it more or less acceptable than forcing the vaccine on her?
3. For common diseases like measles, should the state let people refuse vaccines, even on religious grounds? What if refusing endangers people who cannot be vaccinated, such as people with weakened immune systems?
4. Is it ethical for an individual to refuse the vaccine in this outbreak?
5. At event 5, is it fair to turn the man away? What principle should decide who gets limited doses first?
6. At event 6, should everyone directly exposed be quarantined? What would quarantine require of the government in return?
7. The vaccine's live virus can spread to close contacts. Given that, is it ethical to vaccinate people, including some who don't want it?
8. Today, should health care workers be required, or allowed, to get the smallpox vaccine before any attack? What about other citizens?

**Grading guide (strip before the seminar)**

| Principle | What a strong analysis recognizes |
| --- | --- |
| Harm principle | Smallpox spreads from person to person, so refusing vaccination after exposure risks others, not just oneself. That is the strongest justification for limiting liberty here. |
| Least restrictive alternative | Offering a choice between vaccination and quarantine (event 4) is less intrusive than forced vaccination, and it respects conscience while still protecting others. Strong answers notice this. |
| Justice | With limited supply, giving doses first to the exposed and their contacts ("ring vaccination," the strategy that helped eradicate smallpox) is fair because it targets risk, not status. Turning away the man at event 5 is defensible if the priority rules are transparent and applied equally. |
| Reciprocity | People asked to quarantine are bearing a burden for others. They are owed food, pay protection, medical care and clear communication in return. |
| Informed consent and non-maleficence | The vaccine carries real risks: serious reactions in some groups, and spread of vaccinia to contacts. For people already exposed, the benefit outweighs those risks. For people with no exposure, the balance is different, which is why mass pre-emptive vaccination is a harder call. |
| Respect for autonomy | Religious objections deserve accommodation where it is possible without endangering others. Quarantine is that accommodation here. |

**Strong answers** scale the response to actual exposure, prefer less restrictive measures where they work, explain the duties the state takes on when it restricts people, and use the corrected transmission facts (no spread during incubation) when judging who needs quarantine and when.

**Weak answers** treat any mandate as tyranny or any objection as selfishness; ignore the vaccine's own risks; or argue for quarantining people with no plausible exposure.

## Sources

- Source cases: [Cases in Medical Ethics: Student-Led Discussions](https://www.scu.edu/ethics/focus-areas/bioethics/resources/cases-in-medical-ethics-student-led-discussions/), Markkula Center for Applied Ethics, Santa Clara University (public domain per the page)
- Oregon law: [Oregon Health Authority, Death with Dignity Act FAQ](https://www.oregon.gov:443/oha/PH/PROVIDERPARTNERRESOURCES/EVALUATIONRESEARCH/DEATHWITHDIGNITYACT/Documents/faqs.pdf); [Oregon Legislature, HB 2279 analysis (residency repeal)](https://apps.oregonlegislature.gov/liz/2023r1/Downloads/MeasureAnalysisDocument/79374); [Death with Dignity, Governor signs HB 2279 (2023)](https://deathwithdignity.org/news/2023/07/oregon-governor-tina-kotek-signs/)
- Smallpox: [CDC Smallpox Fact Sheet](https://stacks.cdc.gov/view/cdc/26503/cdc_26503_DS1.pdf); [CDC, Questions and Answers About Smallpox Disease (archived)](https://webarchive.library.unt.edu/web/20090505231513/http://www.bt.cdc.gov/agent/smallpox/faq/smallpox_disease.asp)
- Dax Cowart: [AMA Journal of Ethics](https://journalofethics.ama-assn.org/sites/journalofethics.ama-assn.org/files/2023-02/medu1-0402.pdf); [University of Pittsburgh, "Why Dax Still Matters"](https://bioethics.pitt.edu/sites/default/files/Vandyke%2C%20Why%20Dax%20Still%20Matters.pdf); [Bioethics Today, "A Tribute for Dax Cowart"](https://bioethicstoday.org/blog/a-tribute-for-dax-cowart-1947-2019/); [Wikipedia, Dax Cowart](https://en.wikipedia.org/wiki/Dax_Cowart)
