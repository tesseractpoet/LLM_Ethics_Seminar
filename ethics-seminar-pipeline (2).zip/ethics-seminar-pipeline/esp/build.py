"""Stage 6: select the best candidates and write Together-ready JSONL files.

SFT  (out/sft_train.jsonl, out/sft_val.jsonl):
    {"messages": [system, user, assistant]}   -> train with train_on_inputs=false
DPO  (out/dpo_train.jsonl, out/dpo_val.jsonl):
    {"input": {"messages": [system, user]},
     "preferred_output": [assistant], "non_preferred_output": [assistant]}
Each file gets a parallel *_meta.jsonl (ids, scores, sources) so the training files stay clean.
The validation split is by CASE, never by example, so no case leaks across the split.

build.type_caps limits each item type's share of the TRAIN files (lowest-scoring examples of an
over-represented type are dropped), so seminar talk doesn't drown out decisions and actions.

With build.adaption_formats, out/adaption/ also gets flat files for Adaption's Datasets upload:
    sft_prompt_completion.jsonl/.csv   {"system", "prompt", "completion"}
    dpo_preference.jsonl/.csv          {"system", "prompt", "chosen", "rejected"}
(train split only; keep the val files for your own before/after checks)
"""
from __future__ import annotations

import csv
import re
import statistics
from collections import Counter, defaultdict

from .judge import aggregate
from .util import read_jsonl, write_jsonl


def _eligible(c: dict, a: dict, bcfg: dict, min_score: float) -> bool:
    if c["source"].startswith("negative") or c["source"] == "class":
        return False
    if a["score"] < min_score:
        return False
    if bcfg.get("require_no_flags", True) and (a["caved"] or a["over_refused"]):
        return False
    return True


def _apply_caps(rows: list[dict], meta: list[dict], caps: dict, score_key: str) -> tuple[list, list, dict]:
    """Drop the lowest-scoring rows of any type whose share exceeds its cap. Returns dropped counts."""
    dropped: Counter = Counter()
    pairs = list(zip(rows, meta))
    changed = True
    while changed:
        changed = False
        n = len(pairs)
        counts = Counter(m["type"] for _, m in pairs)
        for typ, cap in caps.items():
            others = n - counts[typ]
            allowed = int(cap * others / (1 - cap)) if cap < 1 else counts[typ]
            if counts[typ] > allowed:
                of_type = sorted((p for p in pairs if p[1]["type"] == typ), key=lambda p: p[1][score_key])
                drop = {id(p[1]) for p in of_type[: counts[typ] - allowed]}
                pairs = [p for p in pairs if id(p[1]) not in drop]
                dropped[typ] += len(drop)
                changed = True
                break
    return [r for r, _ in pairs], [m for _, m in pairs], dropped


def _split_prompt(messages: list[dict]) -> tuple[str, str]:
    system = "\n\n".join(m["content"] for m in messages if m["role"] == "system")
    prompt = "\n\n".join(m["content"] for m in messages if m["role"] == "user")
    return system, prompt


def _write_adaption(out, sft_rows: list[dict], dpo_rows: list[dict]) -> None:
    ad = out / "adaption"
    ad.mkdir(parents=True, exist_ok=True)
    sft_flat = []
    for r in sft_rows:
        system, prompt = _split_prompt(r["messages"][:-1])
        sft_flat.append({"system": system, "prompt": prompt, "completion": r["messages"][-1]["content"]})
    dpo_flat = []
    for r in dpo_rows:
        system, prompt = _split_prompt(r["input"]["messages"])
        dpo_flat.append({"system": system, "prompt": prompt,
                         "chosen": r["preferred_output"][0]["content"],
                         "rejected": r["non_preferred_output"][0]["content"]})
    for name, rows, fields in (("sft_prompt_completion", sft_flat, ["system", "prompt", "completion"]),
                               ("dpo_preference", dpo_flat, ["system", "prompt", "chosen", "rejected"])):
        write_jsonl(ad / f"{name}.jsonl", rows)
        with (ad / f"{name}.csv").open("w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=fields, quoting=csv.QUOTE_ALL)
            w.writeheader()
            w.writerows(rows)


def run(cfg: dict) -> None:
    bcfg = cfg["build"]
    items = read_jsonl(cfg["_data"] / "items.jsonl")
    cands_by_item = defaultdict(list)
    for c in read_jsonl(cfg["_data"] / "candidates.jsonl"):
        cands_by_item[c["item_id"]].append(c)
    agg = aggregate(cfg)
    val_keys = bcfg.get("val_cases", [])
    is_val = lambda case_id: any(k in case_id for k in val_keys)  # noqa: E731

    sft = {"train": [], "val": []}
    dpo = {"train": [], "val": []}
    sft_meta = {"train": [], "val": []}
    dpo_meta = {"train": [], "val": []}
    lengths = {"chosen": [], "rejected": []}
    unjudged = 0

    for it in items:
        split = "val" if is_val(it["case_id"]) else "train"
        scored = []
        for c in cands_by_item.get(it["item_id"], []):
            a = agg.get(c["cand_id"])
            if a is None:
                unjudged += 1
                continue
            scored.append((c, a))
        # class-only attempts (non-teaching class members) are never chosen OR rejected
        scored = [(c, a) for c, a in scored if c["source"] != "class"]
        if not scored:
            continue
        scored.sort(key=lambda ca: ca[1]["score"], reverse=True)

        # --- SFT: top-k eligible candidates
        good = [(c, a) for c, a in scored if _eligible(c, a, bcfg, float(bcfg["sft_min_score"]))]
        for c, a in good[: int(bcfg.get("sft_per_item", 1))]:
            sft[split].append({"messages": it["train_messages"] +
                               [{"role": "assistant", "content": c["text"]}]})
            sft_meta[split].append({"item_id": it["item_id"], "type": it["type"], "case_id": it["case_id"],
                                    "cand_id": c["cand_id"], "model": c["model"], "score": a["score"]})

        # --- DPO: best eligible vs. the hardest rejected that is clearly worse
        chosen_pool = [(c, a) for c, a in scored if _eligible(c, a, bcfg, float(bcfg["dpo_min_chosen"]))]
        if not chosen_pool:
            continue
        ch, cha = chosen_pool[0]
        gap = float(bcfg.get("dpo_min_gap", 3))
        rejected_pool = [(c, a) for c, a in scored if c["cand_id"] != ch["cand_id"]
                         and a["score"] <= cha["score"] - gap]
        if bcfg.get("dpo_prefer_natural", True):
            rejected_pool.sort(key=lambda ca: (ca[0]["source"].startswith("negative"), -ca[1]["score"]))
        else:
            rejected_pool.sort(key=lambda ca: -ca[1]["score"])
        # try to include one "caved" and one "over-refused" rejection when available
        picked, kinds = [], set()
        for c, a in rejected_pool:
            k = "caved" if a["caved"] else "over_refused" if a["over_refused"] else "other"
            if k in kinds and len(rejected_pool) > 1:
                continue
            picked.append((c, a))
            kinds.add(k)
            if len(picked) >= int(bcfg.get("dpo_pairs_per_item", 2)):
                break
        for rj, rja in picked:
            dpo[split].append({"input": {"messages": it["train_messages"]},
                               "preferred_output": [{"role": "assistant", "content": ch["text"]}],
                               "non_preferred_output": [{"role": "assistant", "content": rj["text"]}]})
            dpo_meta[split].append({"item_id": it["item_id"], "type": it["type"], "case_id": it["case_id"],
                                    "chosen": ch["cand_id"], "chosen_score": cha["score"],
                                    "rejected": rj["cand_id"], "rejected_score": rja["score"],
                                    "rejected_source": rj["source"], "rejected_caved": rja["caved"],
                                    "rejected_over_refused": rja["over_refused"]})
            lengths["chosen"].append(len(ch["text"].split()))
            lengths["rejected"].append(len(rj["text"].split()))

    # --- review examples from the practicum debrief (teacher-written notes only)
    if cfg.get("debrief", {}).get("in_training", True):
        from . import prompts as P
        from .debrief import _task_text
        by_item = {it["item_id"]: it for it in items}
        cand_text = {c["cand_id"]: c["text"] for cs in cands_by_item.values() for c in cs}
        banned = re.compile(r"grading guide|rubric|\bgrader\b|\bgraded\b|the grade\b|\b\d+/10\b|"
                            r"\bscored\b|\bthe judge\b|\bthis (test|exercise)\b|\btraining data\b", re.I)
        for r in read_jsonl(cfg["_data"] / "debrief.jsonl"):
            it = by_item.get(r["item_id"])
            if not (r.get("use_for_training") and it and r["cand_id"] in cand_text):
                continue
            if banned.search(r["could_do_better"]):
                continue  # a note that talks about grading would leak the course machinery
            split = "val" if is_val(r["case_id"]) else "train"
            sft[split].append({"messages": [
                {"role": "system", "content": P.REVIEW_TRAIN_SYSTEM},
                {"role": "user", "content": P.REVIEW_TRAIN_TURN.format(task=_task_text(it),
                                                                       response=cand_text[r["cand_id"]])},
                {"role": "assistant", "content": r["could_do_better"]}]})
            # reviews are ranked for the type cap by how informative they are: low-scoring answers first
            sft_meta[split].append({"item_id": r["item_id"], "type": "review", "case_id": r["case_id"],
                                    "cand_id": r["review_id"], "model": r["reviewer"],
                                    "score": 10 - r["score"], "reviewed_answer_score": r["score"]})

    caps = {k: float(v) for k, v in (bcfg.get("type_caps") or {}).items()}
    dropped_sft = dropped_dpo = Counter()
    if caps:
        sft["train"], sft_meta["train"], dropped_sft = _apply_caps(sft["train"], sft_meta["train"], caps, "score")
        dpo["train"], dpo_meta["train"], dropped_dpo = _apply_caps(dpo["train"], dpo_meta["train"], caps,
                                                                   "chosen_score")

    out = cfg["_out"]
    if bcfg.get("adaption_formats", True):
        _write_adaption(out, sft["train"], dpo["train"])
    for split in ("train", "val"):
        write_jsonl(out / f"sft_{split}.jsonl", sft[split])
        write_jsonl(out / f"sft_{split}_meta.jsonl", sft_meta[split])
        write_jsonl(out / f"dpo_{split}.jsonl", dpo[split])
        write_jsonl(out / f"dpo_{split}_meta.jsonl", dpo_meta[split])

    # --- stats report
    lines = ["# Dataset build report", ""]
    for name, meta in (("SFT", sft_meta), ("DPO", dpo_meta)):
        for split in ("train", "val"):
            rows = meta[split]
            by_type = Counter(r["type"] for r in rows)
            lines.append(f"- **{name} {split}:** {len(rows)} examples "
                         f"({', '.join(f'{k} {v}' for k, v in sorted(by_type.items())) or 'none'})")
    for name, d in (("SFT", dropped_sft), ("DPO", dropped_dpo)):
        if d:
            lines.append(f"- {name} train: type caps dropped {', '.join(f'{k} {v}' for k, v in sorted(d.items()))}")
    all_scores = [a["score"] for a in agg.values()]
    if all_scores:
        lines += ["", f"- Candidates judged: {len(all_scores)}; mean score {statistics.mean(all_scores):.2f}",
                  f"- Flagged caved: {sum(a['caved'] for a in agg.values())}; "
                  f"flagged over-refused: {sum(a['over_refused'] for a in agg.values())}"]
    if unjudged:
        lines.append(f"- WARNING: {unjudged} candidates have no judgment yet (run the judge stage).")
    if lengths["chosen"]:
        mc, mr = statistics.mean(lengths["chosen"]), statistics.mean(lengths["rejected"])
        lines.append(f"- DPO mean length: chosen {mc:.0f} words, rejected {mr:.0f} words")
        if mc > 1.3 * mr or mr > 1.3 * mc:
            lines.append("- WARNING: chosen/rejected lengths differ by >30%; DPO may learn length "
                         "instead of judgment. Consider tightening the length guidance in prompts.py.")
    by_case = Counter(r["case_id"] for r in sft_meta["train"])
    thin = [c for c in {it["case_id"] for it in items if not is_val(it["case_id"])}
            if by_case[c] < 5 and not c.startswith("practicum")]  # a task has at most 1 + variants items
    if thin:
        lines.append(f"- Cases with fewer than 5 SFT examples: {', '.join(sorted(thin))}")
    lines += ["", f"- Validation cases: {', '.join(val_keys) or 'none'}"]
    (out / "build_report.md").write_text("\n".join(lines) + "\n")
    print("\n".join(lines))
    print(f"\n  wrote JSONL files to {out}/" + (f" (and Adaption files to {out}/adaption/)"
                                                  if bcfg.get("adaption_formats", True) else ""))
