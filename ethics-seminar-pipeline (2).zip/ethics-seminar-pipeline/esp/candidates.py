"""Stage 4: build training items and generate candidate responses for each.

Item types:
  decision  - one scene: the protagonist's in-the-moment reply (from stage 3)
  challenge - a classmate's challenge from a seminar, and the reply to it (from stage 1)
  analysis  - a seminar question answered standalone
  practicum - an ordinary work task (or a reskinned variant) answered with tool calls

For every item we keep two prompts:
  gen_messages   - what the TEACHER sees while writing a candidate (includes hidden study notes,
                   the glossary and length guidance)
  train_messages - what the STUDENT will see in training (none of that), so the lessons
                   have to end up in the weights

Candidates come from several teacher models, plus (for decision/challenge items) deliberately
flawed negatives used only as DPO "rejected" examples.

Output: data/items.jsonl, data/candidates.jsonl
"""
from __future__ import annotations

import asyncio

from . import prompts as P
from . import practicum
from .cases import participant_view
from .notes import load_notes
from .seminar import load_seminars
from .util import read_jsonl, write_jsonl, append_jsonl

TRAIN_ANALYSIS_SYSTEM = ("You are a thoughtful student of applied ethics answering a seminar question. "
                         "Take a clear position and reason from named principles.")
TRAIN_CHALLENGE_SYSTEM = ("You are a participant in an ethics seminar. A classmate has challenged "
                          "something you said. Respond honestly.")


def build_items(cfg: dict, cases: list[dict], glossaries: dict) -> list[dict]:
    items: list[dict] = []
    by_id = {c["id"]: c for c in cases}
    use_notes = cfg["teacher"].get("use_notes", True)

    def teacher_sys(base: str, case_id: str) -> str:
        notes = load_notes(cfg, case_id) if use_notes else ""
        return base + (P.TEACHER_ADDENDUM.format(notes=notes) if notes else "")

    # decision items
    for s in read_jsonl(cfg["_data"] / "scenes.jsonl"):
        case = by_id.get(s["case_id"])
        if not case:
            continue
        items.append({
            "item_id": f"dec__{s['scene_id']}", "type": "decision", "case_id": case["id"],
            "book": case["book"], "kind": case["kind"],
            "train_messages": [{"role": "system", "content": s["system"]},
                               {"role": "user", "content": s["message"]}],
            "gen_messages": [{"role": "system", "content": teacher_sys(s["system"], case["id"]) + P.DECISION_STYLE},
                             {"role": "user", "content": s["message"]}],
            "neg_messages": [{"role": "system", "content": s["system"] + P.DECISION_STYLE},
                             {"role": "user", "content": s["message"]}],
            "context": f"SYSTEM:\n{s['system']}\n\nMESSAGE:\n{s['message']}",
        })

    # challenge items
    for case in cases:
        glossary = glossaries.get(case["book"], "")
        for sem in load_seminars(cfg, case["id"]):
            for j, d in enumerate(sem["defenses"]):
                user = P.CHALLENGE_ITEM_TURN.format(case_view=participant_view(case, d["event"]),
                                                    prior=d["prior"], challenge=d["challenge"])
                items.append({
                    "item_id": f"chal__{case['id']}__s{sem['seminar']}__{j}", "type": "challenge",
                    "case_id": case["id"], "book": case["book"], "kind": case["kind"],
                    "train_messages": [{"role": "system", "content": TRAIN_CHALLENGE_SYSTEM},
                                       {"role": "user", "content": user}],
                    "gen_messages": [{"role": "system", "content": teacher_sys(
                                         P.CHALLENGE_ITEM_SYSTEM.format(glossary=glossary), case["id"])},
                                     {"role": "user", "content": user}],
                    "neg_messages": [{"role": "system", "content": P.CHALLENGE_ITEM_SYSTEM.format(glossary=glossary)},
                                     {"role": "user", "content": user}],
                    "context": user,
                    "seminar_reply": {"text": d["defense"], "model": d["model"]},
                })

    # analysis items
    for case in cases:
        glossary = glossaries.get(case["book"], "")
        for qi, q in enumerate(case["questions"], 1):
            user = P.ANALYSIS_TURN.format(case_view=participant_view(case), question=q)
            items.append({
                "item_id": f"ana__{case['id']}__q{qi}", "type": "analysis", "case_id": case["id"],
                "book": case["book"], "kind": case["kind"],
                "train_messages": [{"role": "system", "content": TRAIN_ANALYSIS_SYSTEM},
                                   {"role": "user", "content": user}],
                "gen_messages": [{"role": "system", "content": teacher_sys(
                                     P.ANALYSIS_SYSTEM.format(glossary=glossary), case["id"])},
                                 {"role": "user", "content": user}],
                "context": user,
            })
    return items


MAX_TOKENS = {"practicum": 1000}


async def run(llm, cfg: dict, cases: list[dict], glossaries: dict, tasks: list[dict] | None = None) -> None:
    items = build_items(cfg, cases, glossaries) + practicum.build_items(cfg, tasks or [], glossaries)
    write_jsonl(cfg["_data"] / "items.jsonl", items)
    cand_path = cfg["_data"] / "candidates.jsonl"
    have = {c["cand_id"] for c in read_jsonl(cand_path)}

    tcfg, ncfg = cfg["teacher"], cfg.get("negatives", {})
    temp = float(tcfg.get("temperature", 0.8))
    n_per = int(tcfg.get("samples_per_model", 1))
    neg_kinds = ncfg.get("kinds", ["caves", "overrefuses"]) if ncfg.get("enabled", True) else []
    neg_types = set(ncfg.get("item_types", ["decision", "challenge", "practicum"]))

    jobs = []

    async def gen(cand_id, item, model, messages, source, tag):
        text = await llm.chat(model, messages, temperature=temp,
                              max_tokens=MAX_TOKENS.get(item["type"], 700), tag=tag)
        return {"cand_id": cand_id, "item_id": item["item_id"], "model": model,
                "source": source, "text": text}

    for it in items:
        for m in tcfg["models"]:
            for s in range(n_per):
                cid = f"{it['item_id']}__{m}__{s}"
                if cid not in have:
                    jobs.append(gen(cid, it, m, it["gen_messages"], "teacher", f"cand{s}"))
        if it["type"] == "practicum":
            # class members who don't teach take the practicum too (judged and debriefed; never targets)
            for m in cfg["seminar"]["participant_models"]:
                if m not in tcfg["models"]:
                    cid = f"{it['item_id']}__class__{m}"
                    if cid not in have:
                        jobs.append(gen(cid, it, m, it["train_messages"], "class", "class"))
        if it["type"] in neg_types:
            for kind in neg_kinds:
                cid = f"{it['item_id']}__neg_{kind}"
                if cid not in have:
                    base = it.get("neg_messages", it["train_messages"])
                    msgs = [dict(base[0]), base[1]]
                    msgs[0]["content"] += P.NEGATIVE_SYSTEM_SUFFIX[kind]
                    jobs.append(gen(cid, it, ncfg["model"], msgs, f"negative:{kind}", f"neg-{kind}"))
        # a seminar reply becomes a candidate only if its author is a teacher model, so a class
        # member that isn't teaching (e.g. the student's own model family) never writes targets
        if it.get("seminar_reply") and it["seminar_reply"]["model"] in tcfg["models"]:
            cid = f"{it['item_id']}__seminar"
            if cid not in have:
                append_jsonl(cand_path, [{"cand_id": cid, "item_id": it["item_id"],
                                          "model": it["seminar_reply"]["model"], "source": "seminar",
                                          "text": it["seminar_reply"]["text"]}])

    from collections import Counter
    print(f"  {len(items)} items ({', '.join(f'{k} {v}' for k, v in sorted(Counter(i['type'] for i in items).items()))}); generating {len(jobs)} new candidates...")
    batch = []
    for k, coro in enumerate(asyncio.as_completed(jobs), 1):
        batch.append(await coro)
        if len(batch) >= 50 or k == len(jobs):
            append_jsonl(cand_path, batch)
            batch = []
            print(f"    {k}/{len(jobs)} candidates")
