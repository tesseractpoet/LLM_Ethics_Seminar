"""Parse casebook markdown exports into structured cases.

Handles the three casebook formats:
  - Agent casebook v2: "## Case N (agent|human[, grades ...]): Title", rubric under
    "**Facilitator notes (strip before the seminar)**" as bullets.
  - Medical casebook: "## Case N: Title", rubric under "**Grading guide ...**" as a
    table plus "**Strong answers**" / "**Weak answers**" paragraphs.
  - Engineering casebook: "## Case N (grade ...): Title", same rubric shape as medical.
  - Agent supplement and legal casebook: same shapes as above. The supplement has no
    glossary of its own and borrows the agent casebook's.
  - Practicum: "## Task N: Title" work tasks (Role / Tools / Request / Materials / grading
    guide). These are parsed separately by parse_practicum() into data/cases.json["tasks"].

Each case becomes:
  {id, book, number, title, kind ("agent"|"human"), level, setting, principles[],
   prelude (text between setting and events, e.g. a table of asks), events[],
   questions[], rubric (markdown; NEVER shown to seminar participants)}
"""
from __future__ import annotations

import json
import re
from pathlib import Path

BOOKS = {
    "agents_v2.md": "agents",
    "agents_supplement.md": "agentsupp",
    "medical.md": "medical",
    "engineering.md": "engineering",
    "legal.md": "legal",
}
GLOSSARY_FROM = {"agentsupp": "agents"}   # books without a glossary of their own
PRACTICUM_FILE = "practicum.md"

HEAD_RE = re.compile(r"^## Case (\d+)(?: \(([^)]*)\))?: (.+?)\s*$")
RUBRIC_RE = re.compile(r"^\*\*(Facilitator notes|Grading guide)\b.*\*\*\s*$")
LIST_ITEM_RE = re.compile(r"^(\d+)\.\s+(.*)$")


def _slug(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")


def _numbered_items(lines: list[str]) -> list[str]:
    """Collect '1. ...' items; continuation lines are appended to the previous item."""
    items: list[str] = []
    for line in lines:
        m = LIST_ITEM_RE.match(line.strip())
        if m:
            items.append(m.group(2).strip())
        elif line.strip() and items:
            items[-1] += " " + line.strip()
    return items


def parse_casebook(md: str, book: str) -> list[dict]:
    lines = md.splitlines()
    # split into case blocks
    blocks: list[tuple[re.Match, list[str]]] = []
    current = None
    for line in lines:
        m = HEAD_RE.match(line)
        if m:
            current = (m, [])
            blocks.append(current)
            continue
        if line.startswith("## ") and current is not None:
            current = None  # e.g. "## Sources"
            continue
        if current is not None:
            current[1].append(line)

    cases = []
    for m, body in blocks:
        number = int(m.group(1))
        tag = (m.group(2) or "").strip()
        title = m.group(3).strip()
        kind = "agent" if tag.startswith("agent") else "human"
        level_m = re.search(r"(grades?[^,)]*|college[^,)]*)", tag)
        if level_m:
            level = level_m.group(1).strip()
        elif book == "engineering":
            level = tag
        else:
            level = "college"

        sections: dict[str, list[str]] = {"setting": [], "prelude": [], "events": [],
                                           "questions": [], "rubric": []}
        principles: list[str] = []
        mode = "setting"
        for line in body:
            s = line.strip()
            if RUBRIC_RE.match(s):
                mode = "rubric"
                continue
            if mode != "rubric":
                if s.startswith("**Principles in play:**"):
                    principles = [p.strip() for p in s.split(":**", 1)[1].split("·") if p.strip()]
                    mode = "prelude"
                    continue
                if s == "**Events**":
                    mode = "events"
                    continue
                if s == "**Seminar questions**":
                    mode = "questions"
                    continue
            sections[mode].append(line)

        setting = "\n".join(sections["setting"]).strip()
        setting = re.sub(r"^\*\*Setting\.\*\*\s*", "", setting)
        # Medical case 7 has a "Background facts" paragraph before principles: keep it in setting.
        prelude = "\n".join(sections["prelude"]).strip()
        events = _numbered_items(sections["events"])
        questions = _numbered_items(sections["questions"])
        rubric = "\n".join(sections["rubric"]).strip()

        if not events or not questions or not rubric:
            raise ValueError(f"{book} case {number} ({title}) failed to parse: "
                             f"{len(events)} events, {len(questions)} questions, rubric={bool(rubric)}")

        cases.append({
            "id": f"{book}-{number:02d}-{_slug(title)}",
            "book": book,
            "number": number,
            "title": title,
            "kind": kind,
            "level": level,
            "setting": setting,
            "principles": principles,
            "prelude": prelude,
            "events": events,
            "questions": questions,
            "rubric": rubric,
        })
    return cases


def parse_glossary(md: str) -> str:
    """Return the glossary section (markdown) of a casebook, or ''."""
    m = re.search(r"^## Glossary[^\n]*\n(.*?)(?=^## )", md, re.S | re.M)
    return m.group(1).strip() if m else ""


TASK_RE = re.compile(r"^## Task (\d+): (.+?)\s*$")
FIELD_RE = re.compile(r"^\*\*(Role|Tools|Request|Materials)\.\*\*\s*(.*)$")


def parse_practicum(md: str) -> list[dict]:
    """Parse '## Task N: Title' blocks. The grading guide (and the Strong/Weak lines after it)
    becomes the rubric, which only the judge ever sees."""
    m = re.search(r"controls \(Tasks ([^)]*)\)", md)
    controls = {int(n) for n in re.findall(r"\d+", m.group(1))} if m else set()
    tasks, current = [], None
    for line in md.splitlines():
        h = TASK_RE.match(line)
        if h:
            current = {"number": int(h.group(1)), "title": h.group(2).strip(), "lines": []}
            tasks.append(current)
        elif line.startswith("## "):
            current = None
        elif current is not None:
            current["lines"].append(line)

    out = []
    for t in tasks:
        sec = {"role": [], "tools": [], "request": [], "materials": [], "rubric": []}
        mode = None
        for line in t["lines"]:
            s = line.strip()
            if RUBRIC_RE.match(s):
                mode = "rubric"
                continue
            f = FIELD_RE.match(s) if mode != "rubric" else None
            if f:
                mode = f.group(1).lower()
                if f.group(2):
                    sec[mode].append(f.group(2))
                continue
            if mode:
                sec[mode].append(line)
        tools = [re.sub(r"^-\s+", "", l.strip()) for l in sec["tools"] if l.strip().startswith("-")]
        mat = "\n".join(sec["materials"]).strip()
        mat = re.sub(r"^```[a-z]*\n|\n```$", "", mat)
        task = {
            "id": f"practicum-{t['number']:02d}-{_slug(t['title'])}",
            "book": "practicum", "number": t["number"], "title": t["title"],
            "control": t["number"] in controls,
            "role": "\n".join(sec["role"]).strip(),
            "tools": tools,
            "request": "\n".join(sec["request"]).strip(),
            "materials": mat,
            "rubric": "\n".join(sec["rubric"]).strip(),
        }
        if not (task["role"] and tools and task["request"] and task["rubric"]):
            raise ValueError(f"practicum task {t['number']} ({t['title']}) failed to parse")
        out.append(task)
    return out


def task_prompt(task: dict) -> tuple[str, str]:
    """(system, user) for a practicum task, as the agent sees it. No rubric."""
    tools = "\n".join(f"- {t}" for t in task["tools"])
    system = f"{task['role']}\n\nTools available:\n{tools}"
    user = task["request"]
    if task.get("materials"):
        user += f"\n\nAttached:\n{task['materials']}"
    return system, user


def load_all(casebook_dir: Path) -> dict:
    cases, glossaries = [], {}
    for fname, book in BOOKS.items():
        path = casebook_dir / fname
        if not path.exists():
            continue
        md = path.read_text(encoding="utf-8")
        cases.extend(parse_casebook(md, book))
        glossaries[book] = parse_glossary(md)
    for book, src in GLOSSARY_FROM.items():
        if not glossaries.get(book):
            glossaries[book] = glossaries.get(src, "")
    tasks = []
    pf = casebook_dir / PRACTICUM_FILE
    if pf.exists():
        tasks = parse_practicum(pf.read_text(encoding="utf-8"))
    return {"cases": cases, "glossaries": glossaries, "tasks": tasks}


def participant_view(case: dict, upto_event: int | None = None) -> str:
    """The case as seminar participants see it: no rubric. upto_event is 1-based inclusive."""
    events = case["events"] if upto_event is None else case["events"][:upto_event]
    parts = [f"# {case['title']}", "", "## Setting", case["setting"]]
    if case["prelude"]:
        parts += ["", case["prelude"]]
    parts += ["", "## Principles in play", ", ".join(case["principles"]),
              "", "## Events so far"]
    parts += [f"{i}. {e}" for i, e in enumerate(events, 1)]
    return "\n".join(parts)


def main(casebook_dir: str = "casebooks", out: str = "data/cases.json") -> None:
    data = load_all(Path(casebook_dir))
    Path(out).parent.mkdir(parents=True, exist_ok=True)
    Path(out).write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Parsed {len(data['cases'])} cases and {len(data['tasks'])} practicum tasks -> {out}")
    for c in data["cases"]:
        print(f"  {c['id']:<52} {c['kind']:<6} {len(c['events'])} events, "
              f"{len(c['questions'])} questions, level={c['level']}")
    for t in data["tasks"]:
        print(f"  {t['id']:<52} {'control' if t['control'] else 'task':<7} {len(t['tools'])} tools")


if __name__ == "__main__":
    main()
