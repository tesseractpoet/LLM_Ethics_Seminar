"""Debrief stage: after the practicum is graded, tag each answer with what could have been better.

For every practicum answer by a class member (teachers' candidates, and the attempts of class
members who don't teach, such as the student's own model family):
  - its author gets it back with the grade, the judge's comments and the grading guide, and
    writes a short "could have done better" note (kind "self");
  - if the author isn't a teacher, a teacher also writes a note on it (kind "teacher"), so the
    mistakes of non-teaching class members can still reach training.
Notes by teacher models become "review" training examples in the build stage. Notes by
non-teachers are kept for the record only. Held-out (validation) tasks are never debriefed.

Output: data/debrief.jsonl, data/debrief.md (readable)
"""
from __future__ import annotations

import asyncio

from . import prompts as P
from .judge import aggregate
from .util import read_jsonl, append_jsonl


def _task_text(item: dict) -> str:
    return item["context"].replace("SYSTEM:\n", "", 1).replace("\n\nMESSAGE:\n", "\n\nRequest:\n", 1)


async def run(llm, cfg: dict, tasks: list[dict]) -> None:
    dcfg = cfg.get("debrief", {})
    if not dcfg.get("enabled", True):
        print("  debrief disabled in config")
        return
    task_ids = {t["id"] for t in tasks}
    val_keys = cfg["build"].get("val_cases", [])
    teachers = list(cfg["teacher"]["models"])
    items = {i["item_id"]: i for i in read_jsonl(cfg["_data"] / "items.jsonl")
             if i["type"] == "practicum" and i["case_id"] in task_ids
             and not any(k in i["case_id"] for k in val_keys)}
    cands = [c for c in read_jsonl(cfg["_data"] / "candidates.jsonl")
             if c["item_id"] in items and c["source"] in ("teacher", "class")]
    agg = aggregate(cfg)
    path = cfg["_data"] / "debrief.jsonl"
    have = {r["review_id"] for r in read_jsonl(path)}

    async def review(c, reviewer, kind):
        it, a = items[c["item_id"]], agg[c["cand_id"]]
        user = P.DEBRIEF_TURN.format(task=_task_text(it), whose="YOUR" if kind == "self" else "THE AGENT'S",
                                     response=c["text"], score=round(a["score"], 1),
                                     rationale=" / ".join(a["rationales"]) or "(none)", rubric=it["rubric"])
        try:
            r = await llm.chat_json(reviewer, [{"role": "system", "content": P.DEBRIEF_SYSTEM},
                                               {"role": "user", "content": user}],
                                    temperature=0.3, max_tokens=500, tag=f"debrief-{kind}")
        except Exception as e:  # noqa: BLE001
            print(f"    skipped review of {c['cand_id']}: {e}")
            return None
        return {"review_id": f"{c['cand_id']}__rev_{kind}", "item_id": c["item_id"], "case_id": it["case_id"],
                "cand_id": c["cand_id"], "author": c["model"], "reviewer": reviewer, "kind": kind,
                "score": a["score"], "judge_rationale": " / ".join(a["rationales"]),
                "could_do_better": str(r.get("could_do_better", "")).strip(),
                "grade_disagreement": str(r.get("grade_disagreement", "")).strip(),
                "use_for_training": reviewer in teachers}

    jobs, k = [], 0
    for c in cands:
        if c["cand_id"] not in agg:
            continue
        if f"{c['cand_id']}__rev_self" not in have:
            jobs.append(review(c, c["model"], "self"))
        if c["model"] not in teachers and teachers:
            reviewer = teachers[k % len(teachers)]
            k += 1
            if f"{c['cand_id']}__rev_teacher" not in have:
                jobs.append(review(c, reviewer, "teacher"))
    print(f"  debriefing {len(cands)} practicum answers ({len(jobs)} new notes)...")
    rows = [r for r in await asyncio.gather(*jobs) if r and r["could_do_better"]]
    append_jsonl(path, rows)
    _write_readable(cfg, items, {c["cand_id"]: c for c in cands})
    print(f"    wrote {len(rows)} notes -> {path} (readable: {cfg['_data'] / 'debrief.md'})")


def _write_readable(cfg, items, cands):
    rows = read_jsonl(cfg["_data"] / "debrief.jsonl")
    by_item: dict[str, list] = {}
    for r in rows:
        by_item.setdefault(r["item_id"], []).append(r)
    out = ["# Practicum debrief", "",
           "Each answer, its grade, and the class's notes on what could have been done better.", ""]
    for item_id in sorted(by_item):
        it = items.get(item_id)
        if not it:
            continue
        out += [f"## {item_id}", "", "```text", _task_text(it), "```", ""]
        for cand_id in sorted({r["cand_id"] for r in by_item[item_id]}):
            c = cands.get(cand_id)
            notes = [r for r in by_item[item_id] if r["cand_id"] == cand_id]
            out += [f"### Answer by {notes[0]['author']}: {notes[0]['score']:.1f}/10", "",
                    "```text", c["text"] if c else "(missing)", "```", "",
                    f"**Grader:** {notes[0]['judge_rationale']}", ""]
            for r in notes:
                who = "self-review" if r["kind"] == "self" else f"review by {r['reviewer']}"
                out.append(f"**Could have done better ({who}):** {r['could_do_better']}")
                if r["grade_disagreement"]:
                    out.append(f"*Disagrees with the grade:* {r['grade_disagreement']}")
                out.append("")
    (cfg["_data"] / "debrief.md").write_text("\n".join(out), encoding="utf-8")
