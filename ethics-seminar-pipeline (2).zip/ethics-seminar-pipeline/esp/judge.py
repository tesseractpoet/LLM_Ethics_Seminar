"""Stage 5: score every candidate against its case's grading guide.

With several judge models, scores are averaged and flags are OR-ed.
Output: data/judgments.jsonl
"""
from __future__ import annotations

import asyncio

from . import prompts as P
from .cases import participant_view
from .util import read_jsonl, append_jsonl


async def run(llm, cfg: dict, cases: list[dict], tasks: list[dict] | None = None) -> None:
    by_case = {c["id"]: c for c in cases} | {t["id"]: t for t in (tasks or [])}
    items = {i["item_id"]: i for i in read_jsonl(cfg["_data"] / "items.jsonl")}
    cands = read_jsonl(cfg["_data"] / "candidates.jsonl")
    out_path = cfg["_data"] / "judgments.jsonl"
    done = {(j["cand_id"], j["judge"]) for j in read_jsonl(out_path)}
    judges = cfg["judge"]["models"]

    async def score(c, judge_model):
        it = items[c["item_id"]]
        if "rubric" in it:  # practicum items carry their own view and rubric
            view, rubric = it["judge_view"], it["rubric"]
        else:
            case = by_case[it["case_id"]]
            view, rubric = participant_view(case), case["rubric"]
        user = P.JUDGE_TURN.format(case_view_full=view, rubric=rubric,
                                   item_type=it["type"], item_desc=P.ITEM_DESCS[it["type"]],
                                   context=it["context"], response=c["text"])
        try:
            r = await llm.chat_json(judge_model, [{"role": "system", "content": P.JUDGE_SYSTEM},
                                                 {"role": "user", "content": user}],
                                    temperature=0.0, max_tokens=300, tag="judge")
            s = int(r.get("score", 0))
        except Exception as e:  # noqa: BLE001  (unparseable judge output: record and move on)
            r, s = {"rationale": f"judge error: {e}"}, 0
        return {"cand_id": c["cand_id"], "item_id": c["item_id"], "judge": judge_model,
                "score": max(0, min(10, s)), "caved": bool(r.get("caved")),
                "over_refused": bool(r.get("over_refused")), "rationale": r.get("rationale", "")}

    jobs = [score(c, j) for c in cands if c["item_id"] in items and it_ok(items[c["item_id"]], by_case)
            for j in judges if (c["cand_id"], j) not in done]
    print(f"  judging {len(jobs)} candidate/judge pairs...")
    batch = []
    for k, coro in enumerate(asyncio.as_completed(jobs), 1):
        batch.append(await coro)
        if len(batch) >= 50 or k == len(jobs):
            append_jsonl(out_path, batch)
            batch = []
            print(f"    {k}/{len(jobs)} judged")


def it_ok(item: dict, by_case: dict) -> bool:
    return item["case_id"] in by_case  # respects --cases filtering


def aggregate(cfg: dict) -> dict[str, dict]:
    """cand_id -> {score (mean), caved, over_refused, rationales}"""
    agg: dict[str, dict] = {}
    for j in read_jsonl(cfg["_data"] / "judgments.jsonl"):
        a = agg.setdefault(j["cand_id"], {"scores": [], "caved": False, "over_refused": False,
                                          "rationales": []})
        if j["score"] > 0:
            a["scores"].append(j["score"])
        a["caved"] |= j["caved"]
        a["over_refused"] |= j["over_refused"]
        a["rationales"].append(j["rationale"])
    for a in agg.values():
        a["score"] = sum(a["scores"]) / len(a["scores"]) if a["scores"] else 0.0
    return agg
