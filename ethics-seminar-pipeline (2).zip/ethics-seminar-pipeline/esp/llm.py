"""Async OpenRouter client with disk cache, retries, budget cap and a mock mode.

Every call is cached on disk by (model, messages, temperature, max_tokens, tag), so
re-running a stage after a crash or a config tweak costs nothing for work already done.

Every new call is also logged in full (model, tag, every message sent, the reply, cost) to
data/calls.jsonl.gz, so the complete transcript of the run is kept for your write-up.
Read it with:  python tools/show_calls.py   (or any gzip + JSON tool)
"""
from __future__ import annotations

import asyncio
import gzip
import hashlib
import json
import os
import random
import re
import time
from pathlib import Path

OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"
MAX_TOKENS_CEILING = 12000  # retries for cut-off replies stop growing here
MIN_MAX_TOKENS = 4000       # every call gets at least this much room (see _call)


def _json_ok(text: str) -> bool:
    try:
        parse_json(text)
        return True
    except Exception:  # noqa: BLE001
        return False


class BudgetExceeded(RuntimeError):
    pass


class LLM:
    def __init__(self, cfg: dict, mock: bool = False):
        self.cfg = cfg
        self.mock = mock
        self.cache_dir = Path(cfg.get("cache_dir", "data/cache"))
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.sem = asyncio.Semaphore(int(cfg.get("concurrency", 8)))
        self.budget = float(cfg.get("budget_usd", 50))
        self.spent = 0.0
        self.calls = 0
        self.cache_hits = 0
        self._client = None
        self._ledger = self.cache_dir / "_spend.json"
        self._log = Path(cfg.get("_data", "data")) / "calls.jsonl.gz"
        if self._ledger.exists():
            self.spent = json.loads(self._ledger.read_text()).get("spent", 0.0)

    # ------------------------------------------------------------------ public
    async def chat(self, model: str, messages: list[dict], *, temperature: float = 0.7,
                   max_tokens: int = 900, expect_json: bool = False, tag: str = "") -> str:
        parts = [model, messages, temperature, max_tokens, expect_json, tag]
        if self._reasoning(model):
            parts.append(self._reasoning(model))  # only part of the key when set, so old cache stays valid
        key = hashlib.sha256(json.dumps(parts, sort_keys=True).encode()).hexdigest()
        path = self.cache_dir / f"{key}.json"
        if path.exists():
            self.cache_hits += 1
            return json.loads(path.read_text())["content"]

        cost = 0.0
        if self.mock:
            content = _mock_response(messages, expect_json)
        else:
            if self.spent >= self.budget:
                raise BudgetExceeded(f"Budget cap ${self.budget:.2f} reached "
                                     f"(spent ${self.spent:.2f}). Raise budget_usd in config.yaml.")
            async with self.sem:
                content, cost = await self._call(model, messages, temperature, max_tokens, expect_json)
            self.spent += cost
            self._ledger.write_text(json.dumps({"spent": self.spent}))
        self.calls += 1
        if not content.strip() or (expect_json and not _json_ok(content)):
            # never cache an empty or unusable JSON reply, so a rerun tries again
            self._log_call(model, tag, temperature, messages, content, cost)
            return content
        path.write_text(json.dumps({"model": model, "content": content}))
        self._log_call(model, tag, temperature, messages, content, cost)
        return content

    def _log_call(self, model, tag, temperature, messages, content, cost):
        with gzip.open(self._log, "at", encoding="utf-8") as f:
            f.write(json.dumps({"time": time.strftime("%Y-%m-%dT%H:%M:%S"), "model": model, "tag": tag,
                                "temperature": temperature, "messages": messages,
                                "response": content, "cost_usd": cost}, ensure_ascii=False) + "\n")

    async def chat_json(self, model: str, messages: list[dict], **kw) -> dict:
        text = await self.chat(model, messages, expect_json=True, **kw)
        return parse_json(text)

    async def close(self):
        if self._client is not None:
            await self._client.aclose()

    def _reasoning(self, model: str) -> dict | None:
        per = (self.cfg.get("model_reasoning") or {}).get(model)
        if per:
            return dict(per)
        if self.cfg.get("reasoning_effort"):
            return {"effort": self.cfg["reasoning_effort"]}
        return None

    def report(self) -> str:
        return (f"{self.calls} new calls, {self.cache_hits} cache hits, "
                f"total spend so far ${self.spent:.2f} of ${self.budget:.2f} budget")

    # ----------------------------------------------------------------- private
    async def _call(self, model, messages, temperature, max_tokens, expect_json):
        import httpx  # imported lazily so mock mode needs no network packages

        key = get_api_key()
        if not key:
            raise RuntimeError("No API key: put it in openrouter_key.txt (or set OPENROUTER_API_KEY).")
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=180)
        # Thinking models spend part of max_tokens reasoning. Billing is per token actually
        # generated, so a generous cap costs nothing extra and avoids paying for cut-off tries.
        # (Answer length is set by the prompts, not by this cap.)
        body = {"model": model, "messages": messages, "temperature": temperature,
                "max_tokens": max(max_tokens, MIN_MAX_TOKENS), "usage": {"include": True}}
        if expect_json:
            body["response_format"] = {"type": "json_object"}
        if self._reasoning(model):
            body["reasoning"] = self._reasoning(model)
        headers = {"Authorization": f"Bearer {key}", "X-Title": "ethics-seminar-pipeline"}

        delay = 2.0
        for attempt in range(6):
            try:
                r = await self._client.post(OPENROUTER_URL, json=body, headers=headers)
                if r.status_code == 400 and expect_json and "response_format" in body:
                    body.pop("response_format")  # some models reject it; the prompt still asks for JSON
                    continue
                if r.status_code in (429, 500, 502, 503, 504):
                    raise RuntimeError(f"retryable HTTP {r.status_code}: {r.text[:200]}")
                r.raise_for_status()
                data = r.json()
                if "error" in data:
                    raise RuntimeError(str(data["error"])[:300])
                content = data["choices"][0]["message"].get("content") or ""
                finish = data["choices"][0].get("finish_reason") or data["choices"][0].get("native_finish_reason")
                cost = float((data.get("usage") or {}).get("cost") or 0.0)
                cut_off = finish == "length" or (expect_json and not _json_ok(content))
                if (not content.strip() or cut_off) and body["max_tokens"] < MAX_TOKENS_CEILING:
                    # thinking models spend part of the token budget reasoning, which can leave the
                    # reply empty or cut off mid-sentence; give them more room and try again
                    self.spent += cost
                    body["max_tokens"] = min(MAX_TOKENS_CEILING, int(body["max_tokens"] * 2.5))
                    raise RuntimeError(f"reply {'empty' if not content.strip() else 'cut off'}; "
                                       f"retrying with max_tokens={body['max_tokens']}")
                return content.strip(), cost
            except Exception as e:  # noqa: BLE001
                if attempt == 5:
                    raise
                if "retrying with max_tokens" in str(e):
                    continue  # not a server problem: retry right away with more room
                await asyncio.sleep(delay + random.random())
                delay *= 2
        raise RuntimeError("unreachable")


def get_api_key() -> str:
    """OPENROUTER_API_KEY env var if set, else the first line of openrouter_key.txt."""
    key = os.environ.get("OPENROUTER_API_KEY", "").strip()
    if not key:
        f = Path(__file__).resolve().parent.parent / "openrouter_key.txt"
        if f.exists():
            key = f.read_text().strip().splitlines()[0].strip() if f.read_text().strip() else ""
    return key


def parse_json(text: str) -> dict:
    """Parse a JSON object from a model reply, tolerating code fences and chatter."""
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        m = re.search(r"\{.*\}", text, re.S)
        if m:
            return json.loads(m.group(0))
        raise


# --------------------------------------------------------------------- mock mode
def _mock_response(messages: list[dict], expect_json: bool) -> str:
    """Deterministic fake replies so the whole pipeline can be tested offline."""
    sys_text = messages[0]["content"] if messages else ""
    seed = int(hashlib.md5(json.dumps(messages).encode()).hexdigest()[:8], 16)
    rng = random.Random(seed)
    if expect_json:
        if "SCENE_JSON" in sys_text:
            return json.dumps({
                "system": "You are the agent in this scenario. [mock scene system prompt]",
                "message": "[mock incoming message applying pressure]",
                "decision": "[mock: what the protagonist must decide]"})
        if "JUDGE_JSON" in sys_text:
            score = rng.randint(2, 10)
            return json.dumps({"score": score, "caved": score < 4, "over_refused": score in (4, 5),
                               "rationale": "[mock rationale]"})
        if "VARIANT_JSON" in sys_text:
            return json.dumps({"setting": "[mock setting]", "role": "You are the [mock] assistant.",
                               "tools": ["`send(to, text)`: send a message.", "`flag(person, note)`: raise a concern."],
                               "request": "[mock request]", "materials": "[mock materials]",
                               "rubric_map": "[mock rubric map]"})
        if "DEBRIEF_JSON" in sys_text:
            return json.dumps({"could_do_better": f"[mock review {seed % 1000}] It could have included what mattered.",
                               "grade_disagreement": ""})
        if "CHALLENGE_PICK_JSON" in sys_text:
            return json.dumps({"target": "Participant A", "challenge": "[mock challenge]"})
        return json.dumps({"mock": True})
    if "Respond only with the tool calls" in sys_text:
        return f'send(to="requester", text="[mock action {seed % 1000}]")'
    return f"[mock reply {seed % 1000}] I would weigh the principles in play and act accordingly."
