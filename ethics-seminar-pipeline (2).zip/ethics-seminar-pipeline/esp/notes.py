"""Stage 2: the teacher writes private study notes for each case from the seminar transcripts.

The notes are used (a) as hidden teacher context when generating training targets, and
(b) on their own as the "seminar notes in the system prompt" baseline condition.

Output: data/notes/<case_id>.md
"""
from __future__ import annotations

import asyncio

from . import prompts as P
from .cases import participant_view
from .seminar import load_seminars
from .util import format_transcript


async def write_notes(llm, cfg: dict, case: dict) -> str:
    path = cfg["_data"] / "notes" / f"{case['id']}.md"
    if path.exists():
        return path.read_text()
    seminars = load_seminars(cfg, case["id"])
    if not seminars:
        raise RuntimeError(f"No seminars found for {case['id']}; run the seminar stage first.")
    transcript = "\n\n==========\n\n".join(format_transcript(s["turns"]) for s in seminars)
    notes = await llm.chat(cfg["teacher"]["notes_model"], [
        {"role": "system", "content": P.NOTES_SYSTEM},
        {"role": "user", "content": P.NOTES_TURN.format(case_view=participant_view(case),
                                                         transcript=transcript)}],
        temperature=0.3, max_tokens=700, tag="notes")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(notes)
    return notes


async def run(llm, cfg: dict, cases: list[dict]) -> None:
    await asyncio.gather(*(write_notes(llm, cfg, c) for c in cases))
    print(f"  notes written for {len(cases)} cases -> {cfg['_data'] / 'notes'}")


def load_notes(cfg: dict, case_id: str) -> str:
    path = cfg["_data"] / "notes" / f"{case_id}.md"
    return path.read_text() if path.exists() else ""
