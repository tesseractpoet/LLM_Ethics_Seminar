"""Practicum stage: reskin each work task into new settings, and build action-format items.

The 12 practicum tasks skip the seminar, notes and scene stages. Instead:
  1. `variants` asks an LLM to rewrite each task in N new settings (never finance, HR or
     logistics, which are reserved for the swarm test), keeping the ethical structure and
     writing a short "rubric_map" so the judge can apply the original grading guide.
  2. build_items() turns the original plus its variants into items of type "practicum".
     The student sees only the role, tools, request and materials; responses are tool calls.

Output: data/practicum_variants.jsonl
"""
from __future__ import annotations

import asyncio
import random

from . import prompts as P
from .cases import task_prompt
from .util import read_jsonl, append_jsonl

SETTINGS = [
    "a veterinary clinic", "a city transit agency", "a community theater", "a public radio station",
    "a high school athletics department", "a county parks department", "a small architecture firm",
    "a regional food bank", "a hospital volunteer office", "a children's museum", "a local newspaper",
    "a university housing office", "a municipal recycling program", "a dental practice",
    "a youth soccer league", "an art gallery", "a public swimming pool", "a state wildlife agency",
    "a senior center", "a community makerspace", "a botanical garden", "a public health lab",
    "a school district IT office", "a neighborhood association", "a summer camp",
]


def _settings_for(task_id: str, n: int) -> list[str]:
    return random.Random(task_id).sample(SETTINGS, n)


async def run(llm, cfg: dict, tasks: list[dict]) -> None:
    pcfg = cfg.get("practicum", {})
    n = int(pcfg.get("variants_per_task", 4))
    path = cfg["_data"] / "practicum_variants.jsonl"
    have = {v["variant_id"] for v in read_jsonl(path)}

    async def make(task, k, setting):
        user = P.VARIANT_TURN.format(kind="control task: nothing is wrong" if task["control"] else "task",
                                     role=task["role"], tools="\n".join(f"- {t}" for t in task["tools"]),
                                     request=task["request"], materials=task["materials"] or "(none)",
                                     rubric=task["rubric"], setting=setting)
        try:
            r = await llm.chat_json(pcfg.get("model", cfg["scenes"]["model"]),
                                    [{"role": "system", "content": P.VARIANT_SYSTEM},
                                     {"role": "user", "content": user}],
                                    temperature=0.9, max_tokens=1600, tag=f"variant{k}")
            tools = [str(t) for t in r.get("tools", []) if str(t).strip()]
            if not (r.get("role") and r.get("request") and tools):
                raise ValueError("missing fields")
        except Exception as e:  # noqa: BLE001
            print(f"    skipped {task['id']} v{k}: {e}")
            return None
        return {"variant_id": f"{task['id']}__v{k}", "task_id": task["id"], "k": k,
                "setting": r.get("setting", setting), "role": r["role"], "tools": tools,
                "request": r["request"], "materials": r.get("materials", ""),
                "rubric_map": r.get("rubric_map", ""), "control": task["control"]}

    jobs = []
    for t in tasks:
        for k, setting in enumerate(_settings_for(t["id"], n), 1):
            if f"{t['id']}__v{k}" not in have:
                jobs.append(make(t, k, setting))
    print(f"  {len(tasks)} tasks; writing {len(jobs)} new variants...")
    rows = [r for r in await asyncio.gather(*jobs) if r]
    append_jsonl(path, rows)
    print(f"    wrote {len(rows)} variants -> {path}")


def _judge_view(t: dict) -> str:
    system, user = task_prompt(t)
    head = "CONTROL TASK (nothing is actually wrong)" if t.get("control") else "WORK TASK"
    return f"{head}\n\nSYSTEM PROMPT:\n{system}\n\nREQUEST:\n{user}"


def build_items(cfg: dict, tasks: list[dict], glossaries: dict) -> list[dict]:
    variants = {}
    for v in read_jsonl(cfg["_data"] / "practicum_variants.jsonl"):
        variants.setdefault(v["task_id"], []).append(v)
    glossary = glossaries.get("agents", "")
    teacher_extra = (P.PRACTICUM_TEACHER_ADDENDUM.format(glossary=glossary)
                     if cfg["teacher"].get("use_notes", True) else "")
    items = []
    for t in tasks:
        versions = [dict(t, k=0, rubric_map="")] + sorted(variants.get(t["id"], []), key=lambda v: v["k"])
        for v in versions:
            system, user = task_prompt(v)
            rubric = t["rubric"]
            if v["k"]:
                rubric += ("\n\nThis is a reskinned version of the original task (new setting, names and "
                           "tools). How the guide applies here:\n" + v["rubric_map"])
            items.append({
                "item_id": f"prac__{t['id']}__v{v['k']}", "type": "practicum", "case_id": t["id"],
                "book": "practicum", "kind": "agent", "control": t["control"],
                "train_messages": [{"role": "system", "content": system + P.ACTION_FORMAT},
                                   {"role": "user", "content": user}],
                "gen_messages": [{"role": "system", "content": system + teacher_extra + P.ACTION_FORMAT},
                                 {"role": "user", "content": user}],
                "neg_messages": [{"role": "system", "content": system + P.ACTION_FORMAT},
                                 {"role": "user", "content": user}],
                "context": f"SYSTEM:\n{system}\n\nMESSAGE:\n{user}",
                "judge_view": _judge_view(v),
                "rubric": rubric,
            })
    return items
