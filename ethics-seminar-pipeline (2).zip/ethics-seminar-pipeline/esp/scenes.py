"""Stage 3: turn each event into an in-the-moment decision point ("scene").

Agent cases: the trainee plays the AI agent the case follows.
Human cases: by default the trainee plays the human decision-maker (role-play), which keeps
the bridge to agent behavior implicit. Set scenes.human_case_mode: advisor to have the
trainee act as an AI assistant advising that person instead.

Output: data/scenes.jsonl, one row per (case, event, variant); outcome-only events are skipped.
"""
from __future__ import annotations

import asyncio

from . import prompts as P
from .cases import participant_view
from .util import read_jsonl, write_jsonl


async def make_scene(llm, cfg: dict, case: dict, i: int, v: int) -> dict | None:
    if case["kind"] == "agent":
        rule = P.PROTAGONIST_AGENT
    elif cfg["scenes"].get("human_case_mode", "roleplay") == "advisor":
        rule = P.PROTAGONIST_HUMAN_ADVISOR
    else:
        rule = P.PROTAGONIST_HUMAN_ROLEPLAY
    out = await llm.chat_json(cfg["scenes"]["model"], [
        {"role": "system", "content": P.SCENE_SYSTEM.format(protagonist_rule=rule)},
        {"role": "user", "content": P.SCENE_TURN.format(case_view_full=participant_view(case), i=i)}],
        temperature=0.7 if v else 0.3, max_tokens=900, tag=f"scene-v{v}")
    if out.get("skip") or not out.get("system") or not out.get("message"):
        return None
    return {"scene_id": f"{case['id']}__e{i}__v{v}", "case_id": case["id"], "event": i,
            "variant": v, "system": out["system"].strip(), "message": out["message"].strip(),
            "decision": str(out.get("decision", "")).strip()}


async def run(llm, cfg: dict, cases: list[dict]) -> None:
    path = cfg["_data"] / "scenes.jsonl"
    existing = {r["scene_id"]: r for r in read_jsonl(path)}
    n_var = int(cfg["scenes"].get("variants_per_event", 1))
    jobs = [make_scene(llm, cfg, c, i, v) for c in cases
            for i in range(1, len(c["events"]) + 1) for v in range(n_var)]
    results = await asyncio.gather(*jobs)
    for r in results:
        if r:
            existing[r["scene_id"]] = r
    write_jsonl(path, sorted(existing.values(), key=lambda r: r["scene_id"]))
    kept = sum(1 for r in results if r)
    print(f"  {kept} scenes kept, {len(results) - kept} outcome-only events skipped -> {path}")
