"""Stage 1: run multi-model seminars on each case, event by event.

Per event: the facilitator (scripted, not an LLM) reveals the event and asks the
questions that refer to it; each participant answers in turn; then the challenger
picks one participant and challenges them, and that participant responds.
Unassigned questions are asked in a closing round.

Output: data/seminars/<case_id>__s<k>.json
"""
from __future__ import annotations

import asyncio
import json
from pathlib import Path

from . import prompts as P
from .cases import participant_view
from .util import format_transcript, question_events


def assign_questions(case: dict) -> tuple[dict[int, list[str]], list[str]]:
    n = len(case["events"])
    by_event: dict[int, list[str]] = {i: [] for i in range(1, n + 1)}
    closing: list[str] = []
    for q in case["questions"]:
        evs = [e for e in question_events(q) if 1 <= e <= n]
        if evs:
            by_event[max(evs)].append(q)
        else:
            closing.append(q)
    # spread unreferenced questions over events that got none, keep the rest for closing
    empty = [i for i in by_event if not by_event[i]]
    for i in empty:
        if closing and i > 1:  # don't ask big-picture questions before anything happened
            by_event[i].append(closing.pop(0))
    return by_event, closing


async def run_one(llm, cfg: dict, case: dict, glossary: str, k: int) -> dict:
    out_path = cfg["_data"] / "seminars" / f"{case['id']}__s{k}.json"
    if out_path.exists():
        return json.loads(out_path.read_text())

    scfg = cfg["seminar"]
    models = scfg["participant_models"]
    names = scfg["participant_names"]
    n_part = min(int(scfg.get("participants", 3)), len(names))
    # rotate who-is-which-model across seminars for diversity
    roster = [{"name": names[(i + k) % len(names)], "model": models[(i + k) % len(models)]}
              for i in range(n_part)]
    challenger_model = scfg["challenger_model"]
    temp = float(scfg.get("temperature", 0.8))
    by_event, closing = assign_questions(case)
    turns: list[dict] = []
    defenses: list[dict] = []

    async def speak(member, prompt, upto):
        sys = P.PARTICIPANT_SYSTEM.format(name=member["name"], glossary=glossary)
        user = P.PARTICIPANT_TURN.format(case_view=participant_view(case, upto),
                                         transcript=format_transcript(turns), prompt=prompt)
        return await llm.chat(member["model"], [{"role": "system", "content": sys},
                                                {"role": "user", "content": user}],
                              temperature=temp, max_tokens=500, tag=f"sem{k}")

    n_events = len(case["events"])
    for i in range(1, n_events + 1):
        qs = by_event[i] or [P.STAGE_PROMPT_DEFAULT.format(i=i)]
        prompt = f"Event {i} is now on the table. " + " ".join(qs)
        turns.append({"speaker": "Facilitator", "role": "facilitator", "event": i, "content": prompt})
        for m in roster:
            text = await speak(m, prompt, i)
            turns.append({"speaker": m["name"], "role": "participant", "model": m["model"],
                          "event": i, "content": text})
        if scfg.get("challenges", True):
            pick = await llm.chat_json(challenger_model, [
                {"role": "system", "content": P.CHALLENGER_SYSTEM},
                {"role": "user", "content": P.CHALLENGER_TURN.format(
                    case_view=participant_view(case, i), transcript=format_transcript(turns),
                    names=", ".join(m["name"] for m in roster))}],
                temperature=temp, max_tokens=300, tag=f"sem{k}-chal")
            target = next((m for m in roster if m["name"] == pick.get("target")), roster[0])
            challenge = str(pick.get("challenge", "")).strip()
            if challenge:
                turns.append({"speaker": "Challenger", "role": "challenger", "event": i,
                              "content": f"{target['name']}, {challenge}"})
                prior = next((t["content"] for t in reversed(turns)
                              if t["speaker"] == target["name"]), "")
                reply = await speak(target, P.DEFENSE_PROMPT.format(challenger="The challenger",
                                                                    challenge=challenge), i)
                turns.append({"speaker": target["name"], "role": "participant", "model": target["model"],
                              "event": i, "content": reply, "defense": True})
                defenses.append({"event": i, "target": target["name"], "model": target["model"],
                                 "prior": prior, "challenge": challenge, "defense": reply})

    closing_qs = closing or [P.CLOSING_PROMPT_DEFAULT]
    prompt = "Closing round. " + " ".join(closing_qs)
    turns.append({"speaker": "Facilitator", "role": "facilitator", "event": n_events, "content": prompt})
    for m in roster:
        text = await speak(m, prompt, n_events)
        turns.append({"speaker": m["name"], "role": "participant", "model": m["model"],
                      "event": n_events, "content": text})

    result = {"case_id": case["id"], "seminar": k, "roster": roster, "turns": turns,
              "defenses": defenses}
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(result, indent=2, ensure_ascii=False))
    return result


async def run(llm, cfg: dict, cases: list[dict], glossaries: dict) -> None:
    n = int(cfg["seminar"].get("seminars_per_case", 2))
    jobs = [run_one(llm, cfg, c, glossaries.get(c["book"], ""), k)
            for c in cases for k in range(n)]
    done = 0
    for coro in asyncio.as_completed(jobs):
        r = await coro
        done += 1
        print(f"  seminar {done}/{len(jobs)} done: {r['case_id']} #{r['seminar']} "
              f"({len(r['turns'])} turns, {len(r['defenses'])} challenges)")


def load_seminars(cfg: dict, case_id: str) -> list[dict]:
    d = cfg["_data"] / "seminars"
    return [json.loads(p.read_text()) for p in sorted(d.glob(f"{case_id}__s*.json"))]
