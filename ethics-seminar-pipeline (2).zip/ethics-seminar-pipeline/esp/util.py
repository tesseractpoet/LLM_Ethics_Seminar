from __future__ import annotations

import json
import re
from pathlib import Path

import yaml


def load_config(path: str, mock: bool = False) -> dict:
    cfg = yaml.safe_load(Path(path).read_text())
    if mock:
        # keep mock runs completely separate from real data and cache
        cfg["data_dir"] = cfg.get("data_dir", "data") + "_mock"
    data = Path(cfg.get("data_dir", "data"))
    cfg["cache_dir"] = str(data / "cache")
    cfg["_data"] = data
    out_dir = cfg.get("build", {}).get("out_dir", "out")
    cfg["_out"] = data / "out" if mock else Path(out_dir)
    data.mkdir(parents=True, exist_ok=True)
    return cfg


def load_cases(cfg: dict, only: str | None = None) -> tuple[list[dict], dict]:
    path = Path(cfg.get("cases_file", "data/cases.json"))
    d = json.loads(path.read_text(encoding="utf-8"))
    cases = d["cases"]
    if only:
        keys = [k.strip() for k in only.split(",") if k.strip()]
        cases = [c for c in cases if any(k in c["id"] for k in keys)]
    return cases, d["glossaries"]


def load_tasks(cfg: dict, only: str | None = None) -> list[dict]:
    """Practicum tasks. With --cases, only tasks whose id matches (e.g. --cases practicum-01)."""
    path = Path(cfg.get("cases_file", "data/cases.json"))
    tasks = json.loads(path.read_text(encoding="utf-8")).get("tasks", [])
    if only:
        keys = [k.strip() for k in only.split(",") if k.strip()]
        tasks = [t for t in tasks if any(k in t["id"] for k in keys)]
    return tasks


def read_jsonl(path: Path) -> list[dict]:
    if not path.exists():
        return []
    return [json.loads(l) for l in path.read_text(encoding="utf-8").splitlines() if l.strip()]


def write_jsonl(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")


def append_jsonl(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")



def question_events(q: str) -> list[int]:
    """Event numbers a seminar question refers to, e.g. 'At events 2 and 4...' -> [2, 4]."""
    nums = []
    for m in re.finditer(r"\bevents?\s+((?:\d+\s*(?:,|and|to|through|-|–)?\s*)+)", q, re.I):
        nums += [int(n) for n in re.findall(r"\d+", m.group(1))]
    return nums


def format_transcript(turns: list[dict]) -> str:
    if not turns:
        return "(The seminar is just starting.)"
    return "\n\n".join(f"{t['speaker']}: {t['content']}" for t in turns)
