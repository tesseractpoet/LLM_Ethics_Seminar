#!/usr/bin/env python3
"""ethics-seminar-pipeline: casebooks -> seminars -> notes -> scenes -> variants -> candidates -> judge -> debrief -> JSONL

Usage:
  python run.py parse                    # casebooks/*.md -> data/cases.json (already done; rerun after edits)
  python run.py models                   # check model IDs on OpenRouter and save prices
  python run.py estimate                 # approximate calls and cost before spending anything
  python run.py all [--cases agents-01]  # run every stage (resumable; cached calls are free)
  python run.py seminar|notes|scenes|variants|candidates|judge|debrief|build
                                         # variants = practicum reskins; debrief = practicum grading round
Flags:
  --mock         run offline with fake model replies (writes to data_mock/, never spends money)
  --cases X,Y    only cases/tasks whose id contains X or Y (e.g. --cases agents-01,practicum-01)
  --config PATH  config file (default config.yaml)
"""
from __future__ import annotations

import argparse
import asyncio
import json
import sys
from pathlib import Path

from esp import build, candidates, cases as cases_mod, debrief, judge, notes, practicum, scenes, seminar
from esp.llm import LLM, BudgetExceeded, get_api_key
from esp.util import load_cases, load_config, load_tasks

STAGES = ["seminar", "notes", "scenes", "variants", "candidates", "judge", "debrief", "build"]


async def run_stage(stage: str, cfg: dict, llm: LLM, cs: list[dict], gl: dict, ts: list[dict]) -> None:
    print(f"\n=== {stage} ===")
    if stage == "seminar":
        await seminar.run(llm, cfg, cs, gl)
    elif stage == "notes":
        await notes.run(llm, cfg, cs)
    elif stage == "scenes":
        await scenes.run(llm, cfg, cs)
    elif stage == "variants":
        await practicum.run(llm, cfg, ts)
    elif stage == "candidates":
        await candidates.run(llm, cfg, cs, gl, ts)
    elif stage == "judge":
        await judge.run(llm, cfg, cs, ts)
    elif stage == "debrief":
        await debrief.run(llm, cfg, ts)
    elif stage == "build":
        build.run(cfg)
    print(f"  [{llm.report()}]")


def cmd_models(cfg: dict) -> None:
    import httpx
    r = httpx.get("https://openrouter.ai/api/v1/models", timeout=60)
    r.raise_for_status()
    available = {m["id"]: m for m in r.json()["data"]}
    wanted = sorted(_all_models(cfg))
    prices, ok = {}, True
    for m in wanted:
        if m in available:
            p = available[m].get("pricing", {})
            prices[m] = {"prompt": float(p.get("prompt", 0)), "completion": float(p.get("completion", 0))}
            print(f"  OK       {m:<45} ${prices[m]['prompt'] * 1e6:.2f}/M in, "
                  f"${prices[m]['completion'] * 1e6:.2f}/M out")
        else:
            ok = False
            close = [a for a in available if m.split("/")[-1].split("-")[0] in a][:5]
            print(f"  MISSING  {m}   (similar: {', '.join(close) or 'none'})")
    (cfg["_data"] / "prices.json").write_text(json.dumps(prices, indent=2))
    print("\nAll models found." if ok else "\nFix the MISSING ids in config.yaml, then rerun.")


def _all_models(cfg: dict) -> set[str]:
    s = cfg["seminar"]
    return set(s["participant_models"]) | {s["challenger_model"], cfg["teacher"]["notes_model"],
                                           cfg["scenes"]["model"], cfg["negatives"]["model"],
                                           cfg.get("practicum", {}).get("model", cfg["scenes"]["model"])} \
        | set(cfg["teacher"]["models"]) | set(cfg["judge"]["models"])


def cmd_estimate(cfg: dict, cs: list[dict], ts: list[dict]) -> None:
    """Rough call/token/cost estimate. Token sizes are deliberately on the high side."""
    prices = {}
    pf = cfg["_data"] / "prices.json"
    if pf.exists():
        prices = json.loads(pf.read_text())
    default = {"prompt": 1.0e-6, "completion": 4.0e-6}  # used when `run.py models` hasn't been run
    cost = lambda m, i, o: i * prices.get(m, default)["prompt"] + o * prices.get(m, default)["completion"]  # noqa: E731

    s, t = cfg["seminar"], cfg["teacher"]
    n_sem, n_part = int(s["seminars_per_case"]), int(s["participants"])
    rows = []
    calls = tin = tout = usd = 0.0
    # seminar
    c_calls = c_in = c_out = c_usd = 0.0
    for case in cs:
        for _ in range(n_sem):
            turns = 0
            for _e in case["events"]:
                for _p in range(n_part + 2):  # participants + challenger + defense
                    i = 2800 + turns * 260
                    m = s["participant_models"][int(_p) % len(s["participant_models"])]
                    c_calls += 1; c_in += i; c_out += 300; c_usd += cost(m, i, 300)
                    turns += 1
            for _p in range(n_part):
                i = 2800 + turns * 260
                c_calls += 1; c_in += i; c_out += 300; c_usd += cost(s["participant_models"][0], i, 300)
                turns += 1
    rows.append(("seminar", c_calls, c_in, c_out, c_usd))
    # notes
    n = len(cs)
    i = 2000 + n_sem * 40 * 260
    rows.append(("notes", n, n * i, n * 500, n * cost(t["notes_model"], i, 500)))
    # scenes
    n_ev = sum(len(c["events"]) for c in cs) * int(cfg["scenes"]["variants_per_event"])
    rows.append(("scenes", n_ev, n_ev * 2500, n_ev * 600, n_ev * cost(cfg["scenes"]["model"], 2500, 600)))
    # candidates
    n_dec = int(n_ev * 0.85)
    n_chal = sum(len(c["events"]) for c in cs) * n_sem
    n_ana = sum(len(c["questions"]) for c in cs)
    per_item = len(t["models"]) * int(t["samples_per_model"])
    teach_calls = (n_dec + n_chal + n_ana) * per_item
    neg_calls = (n_dec + n_chal) * len(cfg["negatives"]["kinds"]) if cfg["negatives"]["enabled"] else 0
    tc = sum(cost(m, 3500, 380) for m in t["models"]) / len(t["models"])
    rows.append(("candidates", teach_calls + neg_calls, (teach_calls + neg_calls) * 3500,
                 (teach_calls + neg_calls) * 380,
                 teach_calls * tc + neg_calls * cost(cfg["negatives"]["model"], 2500, 380)))
    # practicum: variants, then candidates for original + variants
    pcfg = cfg.get("practicum", {})
    n_var = len(ts) * int(pcfg.get("variants_per_task", 4))
    vm = pcfg.get("model", cfg["scenes"]["model"])
    rows.append(("variants", n_var, n_var * 2500, n_var * 1200, n_var * cost(vm, 2500, 1200)))
    n_prac = len(ts) + n_var
    p_teach = n_prac * per_item
    p_neg = n_prac * len(cfg["negatives"]["kinds"]) if cfg["negatives"]["enabled"] else 0
    rows.append(("practicum", p_teach + p_neg, (p_teach + p_neg) * 1800, (p_teach + p_neg) * 450,
                 p_teach * sum(cost(m, 1800, 450) for m in t["models"]) / len(t["models"])
                 + p_neg * cost(cfg["negatives"]["model"], 1200, 450)))
    n_class = len([m for m in s["participant_models"] if m not in t["models"]])
    p_class = n_prac * n_class
    rows.append(("class-prac", p_class, p_class * 1500, p_class * 450,
                 p_class * sum(cost(m, 1500, 450) for m in s["participant_models"] if m not in t["models"])
                 / max(1, n_class)))
    teach_calls += p_teach + p_class
    neg_calls += p_neg
    if cfg.get("debrief", {}).get("enabled", True):
        n_ans = n_prac * (per_item + n_class)
        n_rev = n_ans + n_prac * n_class
        allm = list(dict.fromkeys(s["participant_models"]))
        rows.append(("debrief", n_rev, n_rev * 3000, n_rev * 200,
                     n_rev * sum(cost(m, 3000, 200) for m in allm) / len(allm)))
    # judge
    n_cand = teach_calls + neg_calls + n_chal
    j_calls = n_cand * len(cfg["judge"]["models"])
    rows.append(("judge", j_calls, j_calls * 4800, j_calls * 150,
                 sum(n_cand * cost(m, 4800, 150) for m in cfg["judge"]["models"])))

    print(f"Estimate for {len(cs)} cases ({'real prices' if prices else 'DEFAULT prices: run `python run.py models` first'}):\n")
    print(f"  {'stage':<12}{'calls':>8}{'input tok':>13}{'output tok':>13}{'cost':>10}")
    for name, c, i, o, u in rows:
        print(f"  {name:<12}{int(c):>8}{int(i):>13,}{int(o):>13,}{u:>10.2f}")
        calls += c; tin += i; tout += o; usd += u
    print(f"  {'TOTAL':<12}{int(calls):>8}{int(tin):>13,}{int(tout):>13,}{usd:>10.2f}")
    print(f"\n  Expected items: ~{n_dec} decision, {n_chal} challenge, {n_ana} analysis, "
          f"{n_prac} practicum (~{n_dec + n_chal + n_ana + n_prac} total, before quality filtering)")
    print(f"  Budget cap in config: ${cfg['budget_usd']}")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("command", choices=["parse", "models", "estimate", "all"] + STAGES)
    ap.add_argument("--mock", action="store_true")
    ap.add_argument("--cases", default=None)
    ap.add_argument("--config", default="config.yaml")
    args = ap.parse_args()

    if args.command == "parse":
        cases_mod.main("casebooks", "data/cases.json")
        return
    cfg = load_config(args.config, mock=args.mock)
    if args.command == "models":
        cmd_models(cfg)
        return
    cs, gl = load_cases(cfg, args.cases)
    ts = load_tasks(cfg, args.cases)
    if not cs and not ts:
        sys.exit(f"No cases or practicum tasks match --cases {args.cases!r}")
    if args.command == "estimate":
        cmd_estimate(cfg, cs, ts)
        return

    if not args.mock and args.command != "build" and not get_api_key():
        sys.exit("No API key found. Paste it into openrouter_key.txt (see README step 0), "
                 "or add --mock to test offline.")

    async def go():
        llm = LLM(cfg, mock=args.mock)
        try:
            for st in (STAGES if args.command == "all" else [args.command]):
                await run_stage(st, cfg, llm, cs, gl, ts)
        except BudgetExceeded as e:
            print(f"\nSTOPPED: {e}\nEverything finished so far is saved; rerun the same command to resume.")
        finally:
            await llm.close()

    asyncio.run(go())


if __name__ == "__main__":
    main()
