"""Leak check: runs the whole pipeline offline (mock mode) and proves no grading guide text
reaches anyone but the judge (and the practicum reskin writer), or any training file.

Usage:  python tools/check_hidden.py      (free; writes to data_mock/)
"""
import asyncio, json, re, sys
sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parents[1]))
import esp.llm as L
calls = []
orig = L.LLM.chat
async def spy(self, model, messages, *a, **k):
    calls.append(messages)
    return await orig(self, model, messages, *a, **k)
L.LLM.chat = spy
import run
sys.argv = ["run.py", "all", "--mock"]
run.main()

d = json.load(open("data/cases.json"))
units = d["cases"] + d["tasks"]
# 1. parser boundary: visible fields must contain no rubric-looking text
VIS = ["setting", "prelude", "principles", "events", "questions", "role", "tools", "request", "materials"]
bad_markers = re.compile(r"Strong (answers|responses)|Weak (answers|responses)|strip before|Grading guide|Facilitator notes|What a strong", re.I)
for u in units:
    for f in VIS:
        if f in u and bad_markers.search(json.dumps(u[f])):
            print("BOUNDARY PROBLEM", u["id"], f)
# 2. fingerprints: every sentence of every rubric, 8+ words
fps = set()
for u in units:
    for sent in re.split(r"(?<=[.!?])\s+|\|", u["rubric"]):
        w = re.sub(r"[*`]", "", sent).strip()
        if len(w.split()) >= 8: fps.add(w)
seen = {"rubric-allowed": 0, "other": 0}; leaks = 0
for m in calls:
    sys_txt = m[0]["content"]
    allowed = any(k in sys_txt for k in ("JUDGE_JSON", "VARIANT_JSON", "DEBRIEF_JSON"))
    seen["rubric-allowed" if allowed else "other"] += 1
    if allowed: continue
    blob = "\n".join(x["content"] for x in m)
    for fp in fps:
        if fp in blob:
            leaks += 1; print("LEAK in non-judge call:", fp[:70]); break
print(f"{len(units)} cases/tasks, {len(fps)} rubric sentences fingerprinted")
print(f"calls that may see the rubric (judge, reskin writer, debrief): {seen['rubric-allowed']}")
print(f"all other calls (class, challenger, notes, scenes, teachers, negatives): {seen['other']}, leaks: {leaks}")
# 3. training files
# 3. training files. Debrief "review" examples are allowed to carry the guide's lessons (by
# design: that's how past mistakes are passed down), so they're counted separately.
import glob
from esp.prompts import REVIEW_TRAIN_SYSTEM
tl = rv = 0
for f in glob.glob("data_mock/out/*.jsonl") + glob.glob("data_mock/out/adaption/*.jsonl"):
    if "meta" in f: continue
    for line in open(f):
        n = sum(fp in line for fp in fps)
        if REVIEW_TRAIN_SYSTEM in line: rv += n
        else: tl += n
print("rubric sentences found in training files (outside debrief reviews):", tl)
print("rubric sentences quoted word for word in debrief reviews (allowed, shown for info):", rv)
