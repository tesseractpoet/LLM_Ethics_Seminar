"""Print the full log of model calls (data/calls.jsonl.gz) as readable text.

  python tools/show_calls.py                 # everything
  python tools/show_calls.py judge           # only calls whose tag or model contains "judge"
  python tools/show_calls.py qwen > qwen.txt # save to a file
"""
import gzip
import json
import sys
from pathlib import Path

path = Path("data/calls.jsonl.gz")
if not path.exists():
    sys.exit("No log yet: data/calls.jsonl.gz is created by the first real run.")
want = sys.argv[1].lower() if len(sys.argv) > 1 else ""
with gzip.open(path, "rt", encoding="utf-8") as f:
    for line in f:
        c = json.loads(line)
        if want and want not in (c["tag"] + " " + c["model"]).lower():
            continue
        print(f"\n{'=' * 80}\n{c['time']}  {c['model']}  [{c['tag']}]  ${c['cost_usd']:.4f}\n{'=' * 80}")
        for m in c["messages"]:
            print(f"--- {m['role'].upper()} ---\n{m['content']}")
        print(f"--- REPLY ---\n{c['response']}")
