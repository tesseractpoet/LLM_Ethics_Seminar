#!/usr/bin/env python3
"""Check SFT and DPO JSONL files against Together's fine-tuning formats before uploading.

  python tools/validate_jsonl.py out/sft_train.jsonl out/dpo_train.jsonl ...
"""
import json
import sys

ROLES = {"system", "user", "assistant"}


def check_sft(row):
    msgs = row.get("messages")
    assert isinstance(msgs, list) and msgs, "missing messages"
    for m in msgs:
        assert m.get("role") in ROLES, f"bad role {m.get('role')}"
        assert isinstance(m.get("content"), str) and m["content"].strip(), "empty content"
    assert msgs[-1]["role"] == "assistant", "last message must be assistant"
    assert set(row) == {"messages"}, f"extra fields: {set(row) - {'messages'}}"


def check_dpo(row):
    assert set(row) == {"input", "preferred_output", "non_preferred_output"}, f"fields: {set(row)}"
    msgs = row["input"]["messages"]
    assert msgs and msgs[-1]["role"] == "user", "input must end with a user message"
    for m in msgs:
        assert m.get("role") in ROLES and m.get("content", "").strip(), "bad input message"
    for k in ("preferred_output", "non_preferred_output"):
        out = row[k]
        assert isinstance(out, list) and len(out) == 1, f"{k} must hold exactly one message"
        assert out[0]["role"] == "assistant" and out[0]["content"].strip(), f"{k} must be a non-empty assistant message"
    assert row["preferred_output"][0]["content"] != row["non_preferred_output"][0]["content"], "identical pair"


def main(paths):
    bad = 0
    for p in paths:
        rows = [json.loads(l) for l in open(p, encoding="utf-8") if l.strip()]
        kind = "dpo" if rows and "input" in rows[0] else "sft"
        errs = 0
        for n, r in enumerate(rows, 1):
            try:
                (check_dpo if kind == "dpo" else check_sft)(r)
            except AssertionError as e:
                errs += 1
                if errs <= 5:
                    print(f"  {p}:{n}: {e}")
        print(f"{p}: {len(rows)} {kind.upper()} rows, {errs} errors")
        bad += errs
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main(sys.argv[1:])
